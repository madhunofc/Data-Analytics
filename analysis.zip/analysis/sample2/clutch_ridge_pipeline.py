"""
SAMPLE 2 — Opposition-adjusted ridge model with continuous pressure ("Clutch RAPM")
-----------------------------------------------------------------------------------
Usage:  python clutch_ridge_pipeline.py <data_dir> <out_dir> [<sample1_out_dir>]

Self-contained (does not import or change ../pressure_pipeline.py). Steps 1-5 rebuild the same
match state, win-probability models, Leverage Index and per-ball Run Value as Sample 1.
What is different:

 6. No pressure threshold. Pressure is a continuous covariate z = standardised log(pressure score).
 7. One ridge regression per side on every ball:
        RV_ball = mu + g*z + a[player] + b[player]*z + a[opponent] + b[opponent]*z + e
    a = player's level, b = how that level changes with pressure. Opponent terms adjust for
    who they faced. Ridge = Gaussian random effects, so small samples shrink toward 0 (average).
 8. Penalties (lambda for levels, lambda*r for slopes) chosen by match-grouped cross-validation.
 9. Clutch rating = a + b * z(90th pct pressure) = expected run value per ball at a high-pressure ball,
    against average opposition. Normal rating = a + b * z(median). Lift = difference.
10. Uncertainty: 100 Poisson bootstrap refits by match. Reliability: split-half correlation,
    compared with Sample 1's simple "mean run value on pressure balls".
"""
import sys, json, re
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.optimize import curve_fit
from scipy.stats import spearmanr, pearsonr
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.model_selection import GroupKFold

DATA, OUT = Path(sys.argv[1]), Path(sys.argv[2])
S1 = Path(sys.argv[3]) if len(sys.argv) > 3 else None
OUT.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(7)
BAT_MIN_BALLS, BAT_MIN_PBALLS = 300, 100       # same eligibility as Sample 1 so the lists are comparable
BOWL_MIN_BALLS, BOWL_MIN_PBALLS = 360, 120
HI_Q, MID_Q = 0.90, 0.50
N_BOOT, N_SPLIT = 100, 6
LAMBDAS, RATIOS = [30, 100, 300, 1000, 3000], [1, 4, 16, 64]
log = {}

# =============================================================== 1-2. load, clean, state
b1 = pd.read_csv(DATA / "ball_by_ball-1.csv")
b2 = pd.read_csv(DATA / "ball_by_ball-2.csv", header=None, names=b1.columns)
bb = pd.concat([b1, b2], ignore_index=True)
matches = pd.read_csv(DATA / "matches.csv"); comps = pd.read_csv(DATA / "competitions.csv"); teams = pd.read_csv(DATA / "teams.csv")
m = matches.merge(comps[["comp_id", "comp_name", "match_format", "season"]], on="comp_id", how="left")
m["comp_type"] = np.where(m.comp_name.str.contains("IPL", na=False), "IPL", np.where(m.match_format.eq("T20I"), "T20I", "Other T20"))
m["reduced"] = m[["first_inn_revised_overs", "second_inn_revised_overs", "revised_target"]].notna().any(axis=1)
m["has_winner"] = m.win_team_id.notna() & (m.win_team_id > 0)
m["is_ko"] = (m.knock_out.eq(1) | m.stage.isin(["Final", "Qualifier", "Eliminator", "Semi Final"])).astype(int)
m["year"] = m.match_date.str[:4].astype(int)
def margin(res):
    r = re.search(r"by (\d+)\s*(run|wicket|wkt)", str(res), re.I)
    return (int(r.group(1)), "runs" if r.group(2).lower().startswith("run") else "wkts") if r else (np.nan, None)
mm = m.result.apply(margin); m["margin_n"] = [x[0] for x in mm]; m["margin_type"] = [x[1] for x in mm]

bb = bb[bb.innings.isin([1, 2])]
bb = bb[bb.match_id.isin(m.loc[(~m.reduced) & m.has_winner, "match_id"])].copy()
bb = bb.merge(m[["match_id", "comp_type", "year", "is_ko", "win_team_id"]], on="match_id", how="left")
bb = bb.sort_values(["match_id", "innings", "innings_ball_num"]).reset_index(drop=True)

et = bb.extras_type.fillna("None"); e2 = bb.extras_2_runs.fillna(0)
bb["is_wide"] = et.eq("wide"); bb["is_nb"] = et.eq("Overstep")
bb["legal"] = ~(bb.is_wide | bb.is_nb); bb["faced"] = ~bb.is_wide
extra = np.select([bb.is_wide | bb.is_nb, et.isin(["byes", "legbyes"]), et.eq("Penalty")], [1 + e2, np.maximum(1, e2), 5 + e2], default=e2)
bb["team_runs"] = bb.runs + extra
bb["bowler_conc"] = bb.runs + np.where(bb.is_wide | bb.is_nb, 1 + e2, 0)
bb["wkt"] = bb.is_wicket.astype(bool)
bb["batter_out"] = bb.wkt & (bb.dismissed_player_id.eq(bb.striker_id) | (bb.dismissed_player_id.isna() & ~bb.dismissal_type.eq("RunOut")))
bb["bowler_wkt"] = bb.wkt & bb.dismissal_type.isin(["Caught", "Bowled", "LBW", "Stump", "Hit Wicket"])
bb["phase"] = pd.cut(bb.overid, [0, 6, 15, 20], labels=["PP", "Middle", "Death"]).astype(str)
g = bb.groupby(["match_id", "innings"], sort=False)
bb["score_b"] = g.team_runs.cumsum() - bb.team_runs; bb["wk_b"] = g.wkt.cumsum() - bb.wkt; bb["lb_b"] = g.legal.cumsum() - bb.legal
bb["score_a"] = bb.score_b + bb.team_runs; bb["wk_a"] = bb.wk_b + bb.wkt; bb["lb_a"] = bb.lb_b + bb.legal

tot = bb.groupby(["match_id", "innings"]).team_runs.sum().unstack()
tg = pd.DataFrame({"inn1": tot[1], "inn2": tot[2], "bat2": bb[bb.innings == 2].groupby("match_id").batting_team_id.first()}).dropna(subset=["inn1"])
tg = tg.join(m.set_index("match_id")[["win_team_id", "margin_n"]]); tg["target"] = tg.inn1 + 1
cw = tg.win_team_id.eq(tg.bat2); fa = cw & (tg.inn2 < tg.target); fb = (~cw) & tg.inn2.notna() & (tg.inn2 >= tg.target)
tg.loc[fa, "target"] = tg.loc[fa, "inn2"]; tg.loc[fb, "target"] = tg.loc[fb, "inn2"] + tg.loc[fb, "margin_n"].fillna(0).clip(lower=0) + 1
bb = bb.merge(tg[["target"]], left_on="match_id", right_index=True, how="left")
bb["bat_won"] = bb.win_team_id.eq(bb.batting_team_id).astype(int); bb["ipl"] = bb.comp_type.eq("IPL").astype(int)
bb = bb[bb.target.notna()].reset_index(drop=True)
log["balls_used"] = int(len(bb)); log["matches_used"] = int(bb.match_id.nunique())

# =============================================================== 3. win probability (same spec as Sample 1)
HGB = dict(max_iter=200, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=1500, l2_regularization=5.0, random_state=42)
def _logit(p): p = np.clip(p, 1e-4, 1 - 1e-4); return np.log(p / (1 - p)).reshape(-1, 1)
def f1(score, wk, lb, ipl): lb = np.where(wk >= 10, 120, lb); return np.column_stack([score, wk, lb, score * 6 / np.maximum(lb, 1), ipl])
def f2(need, bl, wih, target, ipl): return np.column_stack([need, bl, wih, np.clip(need * 6 / np.maximum(bl, 1), 0, 36), target, ipl])
def fit_wp(X, y, grp, mono):
    oof = np.zeros(len(y))
    for tr, te in GroupKFold(5).split(X, y, grp):
        oof[te] = HistGradientBoostingClassifier(monotonic_cst=mono, **HGB).fit(X[tr], y[tr]).predict_proba(X[te])[:, 1]
    platt = LogisticRegression().fit(_logit(oof), y)
    full = HistGradientBoostingClassifier(monotonic_cst=mono, **HGB).fit(X, y)
    return lambda Xn: platt.predict_proba(_logit(full.predict_proba(Xn)[:, 1]))[:, 1]
i1 = bb[bb.innings == 1]
t1 = i1.groupby("match_id").agg(score=("score_a", "last"), wk=("wk_a", "last"), ipl=("ipl", "first"), y=("bat_won", "first"))
M1 = fit_wp(np.vstack([f1(i1.score_b, i1.wk_b, i1.lb_b, i1.ipl), f1(t1.score, t1.wk, np.full(len(t1), 120), t1.ipl)]),
            np.concatenate([i1.bat_won, t1.y]), np.concatenate([i1.match_id, t1.index]), [1, -1, -1, 1, 0])
i2 = bb[bb.innings == 2]; need = i2.target - i2.score_b; bl = 120 - i2.lb_b; wih = 10 - i2.wk_b; ok = (need > 0) & (bl > 0) & (wih > 0)
M2 = fit_wp(f2(need[ok], bl[ok], wih[ok], i2.target[ok], i2.ipl[ok]), i2.bat_won[ok].values, i2.match_id[ok].values, [-1, 1, 1, -1, 0, 0])
def wp2(need, bl, wih, target, ipl):
    need, bl, wih = (np.asarray(v, float) for v in (need, bl, wih)); out = np.full(len(need), np.nan)
    won = need <= 0; tie = (need == 1) & ((bl <= 0) | (wih <= 0)); lost = ~won & ~tie & ((bl <= 0) | (wih <= 0))
    out[won], out[tie], out[lost] = 1.0, 0.5, 0.0; live = np.isnan(out)
    if live.any(): out[live] = M2(f2(need[live], bl[live], wih[live], np.asarray(target)[live], np.asarray(ipl)[live]))
    return out
def wp_state(df, dr, dw, db):
    res = np.zeros(len(df)); a = (df.innings == 1).values; d = df[a]
    res[a] = M1(f1(d.score_b + dr, np.minimum(d.wk_b + dw, 10), np.minimum(d.lb_b + db, 120), d.ipl)); d = df[~a]
    res[~a] = wp2(d.target - d.score_b - dr, 120 - d.lb_b - db, 10 - d.wk_b - dw, d.target, d.ipl); return res
bb["wp_b"] = wp_state(bb, 0, 0, 0)

# =============================================================== 4. leverage + pressure score (same as Sample 1)
bb["oc"] = np.where(bb.is_wide | bb.is_nb, "X", np.where(bb.wkt, "W", bb.team_runs.clip(upper=6).replace({5: 4}).astype(int).astype(str)))
probs = bb.groupby(["innings", "phase"]).oc.value_counts(normalize=True).unstack(fill_value=0)
OUTC = {"0": (0, 0, 1), "1": (1, 0, 1), "2": (2, 0, 1), "3": (3, 0, 1), "4": (4, 0, 1), "6": (6, 0, 1), "W": (0, 1, 1), "X": (1, 0, 0)}
lev = np.zeros(len(bb)); pk = pd.MultiIndex.from_arrays([bb.innings, bb.phase])
for oc, (dr, dw, db) in OUTC.items():
    lev += probs[oc].reindex(pk).values * np.abs(wp_state(bb, dr, dw, db) - bb.wp_b.values)
bb["LI"] = lev / lev.mean()
w18 = np.zeros(len(bb)); r18 = np.zeros(len(bb))
for _, idx in bb.groupby(["match_id", "innings"], sort=False).indices.items():
    L = bb.lb_b.values[idx]; j = np.searchsorted(L, L - 18, side="left")
    w18[idx] = bb.wk_b.values[idx] - bb.wk_b.values[idx][j]; r18[idx] = bb.score_b.values[idx] - bb.score_b.values[idx][j]
ko = np.where(bb.is_ko.eq(1), 1.25, 1.0)
bb["bat_ps"] = bb.LI * ko * np.where(w18 >= 2, 1.2, 1.0)
bb["bowl_ps"] = bb.LI * ko * np.where((r18 >= 30) & (bb.lb_b >= 18), 1.2, 1.0)

# =============================================================== 5. expected outcomes + run value (same as Sample 1)
bb["wb"] = pd.cut(bb.wk_b, [-1, 1, 3, 5, 10], labels=["0-1", "2-3", "4-5", "6+"]).astype(str)
FINE = ["innings", "phase", "overid", "wb", "pace_or_spin", "comp_type"]; COARSE = ["innings", "phase", "wb"]
def smooth_mean(df, val, k=40):
    c = df.groupby(COARSE)[val].mean().rename("c").reset_index()
    f = df.groupby(FINE)[val].agg(["sum", "count"]).reset_index().merge(c, on=COARSE)
    f["m"] = (f["sum"] + k * f["c"]) / (f["count"] + k)
    return df[FINE].merge(f[FINE + ["m"]], on=FINE, how="left")["m"].values
i1 = bb[bb.innings == 1]; rem = (i1.groupby("match_id").team_runs.transform("sum") - i1.score_b)
u_all, w_all, r_all = (120 - i1.lb_b).values, i1.wk_b.values, rem.values
RE = np.zeros((121, 11))
for w in range(10):
    sel = w_all >= w if w >= 7 else w_all == w
    (a, c), _ = curve_fit(lambda u, a, c: a * (1 - np.exp(-c * u)), u_all[sel], r_all[sel], p0=[200, 0.01], bounds=([0, 1e-5], [600, 1]))
    RE[:, w] = a * (1 - np.exp(-c * (120 - np.arange(121))))
RE = np.minimum.accumulate(RE, axis=1); WC = np.clip(RE[:, :-1] - RE[:, 1:], 0, None)
bb["wc"] = WC[np.clip(bb.lb_b, 0, 119).astype(int), np.clip(bb.wk_b, 0, 9).astype(int)]

bat = bb[bb.faced].copy()
bat["xr"] = smooth_mean(bat, "runs"); bat["xo"] = smooth_mean(bat, "batter_out")
bat["rv"] = (bat.runs - bat.xr) - bat.wc * (bat.batter_out.astype(float) - bat.xo)
bowl = bb.copy()
bowl["xc"] = smooth_mean(bowl, "bowler_conc"); bowl["xw"] = smooth_mean(bowl, "bowler_wkt")
bowl["rv"] = (bowl.xc - bowl.bowler_conc) + bowl.wc * (bowl.bowler_wkt.astype(float) - bowl.xw)

# =============================================================== 6. continuous pressure covariate
for df, ps in ((bat, "bat_ps"), (bowl, "bowl_ps")):
    lz = np.log(df[ps].clip(lower=0.02))
    df["z"] = ((lz - lz.mean()) / lz.std()).clip(-3, 3)
    df["p"] = df[ps] >= df[ps].quantile(0.75)          # only for descriptive stats + eligibility (same as Sample 1)
Z = {k: dict(hi=float(df.z.quantile(HI_Q)), mid=float(df.z.quantile(MID_Q))) for k, df in (("bat", bat), ("bowl", bowl))}
log["z_points"] = Z

# =============================================================== 7-8. ridge model + CV
class Side:
    def __init__(self, df, own, opp, nmin, pmin, ncol):
        self.df = df.reset_index(drop=True)
        self.own_ids, own_code = np.unique(self.df[own], return_inverse=True)
        self.opp_ids, opp_code = np.unique(self.df[opp], return_inverse=True)
        n, z = len(self.df), self.df.z.values; r = np.arange(n)
        no, np_ = len(self.own_ids), len(self.opp_ids)
        self.A_own = sparse.csr_matrix((np.ones(n), (r, own_code)), shape=(n, no))
        self.A_opp = sparse.csr_matrix((np.ones(n), (r, opp_code)), shape=(n, np_))
        self.B_own = sparse.csr_matrix((z, (r, own_code)), shape=(n, no))
        self.B_opp = sparse.csr_matrix((z, (r, opp_code)), shape=(n, np_))
        self.G = sparse.csr_matrix(z.reshape(-1, 1))
        self.y = self.df.rv.values; self.grp = self.df.match_id.values; self.no = no; self.np_ = np_
        cnt = self.df.assign(pn_=self.df.p & self.df[ncol]).groupby(own).agg(n=(ncol, "sum"), pn=("pn_", "sum"))
        self.elig = cnt.index[(cnt.n >= nmin) & (cnt.pn >= pmin)]
        self.own = own
    def X(self, r):
        s = 1 / np.sqrt(r)          # slope penalty = lambda * r
        return sparse.hstack([self.A_own, self.A_opp, self.B_own * s, self.B_opp * s, self.G * 30]).tocsr(), s
    def fit(self, lam, r, idx=None, w=None):
        X, s = self.X(r)
        if idx is not None: X, y, w = X[idx], self.y[idx], (None if w is None else w[idx])
        else: y = self.y
        mdl = Ridge(alpha=lam, solver="sparse_cg", tol=1e-6, max_iter=3000).fit(X, y, sample_weight=w)
        c = mdl.coef_; no, np_ = self.no, self.np_
        a = c[:no]; b = c[no + np_: 2 * no + np_] * s
        return pd.DataFrame({"a": a, "b": b}, index=self.own_ids), mdl, X

R = {"bat": Side(bat, "striker_id", "bowler_id", BAT_MIN_BALLS, BAT_MIN_PBALLS, "faced"),
     "bowl": Side(bowl, "bowler_id", "striker_id", BOWL_MIN_BALLS, BOWL_MIN_PBALLS, "legal")}

cv_rows = []
for k, S in R.items():
    folds = list(GroupKFold(3).split(np.zeros(len(S.y)), S.y, S.grp))
    null_mse = np.mean([np.mean((S.y[te] - S.y[tr].mean()) ** 2) for tr, te in folds])
    best = None
    for lam in LAMBDAS:
        for r in RATIOS:
            X, _ = S.X(r); mse = []
            for tr, te in folds:
                mdl = Ridge(alpha=lam, solver="sparse_cg", tol=1e-5, max_iter=2000).fit(X[tr], S.y[tr])
                mse.append(np.mean((S.y[te] - mdl.predict(X[te])) ** 2))
            mse = float(np.mean(mse)); gain = (null_mse - mse) / null_mse * 100
            cv_rows.append(dict(key=f"{k}-{lam}-{r}", side="Batting" if k == "bat" else "Bowling", lam=lam, slope_ratio=r,
                                mse=round(mse, 5), gain_pct=round(gain, 4)))
            if best is None or mse < best[0]: best = (mse, lam, r, gain)
            print(k, lam, r, round(mse, 5), round(gain, 4), flush=True)
    S.lam, S.r = best[1], best[2]
    log[f"cv_{k}"] = dict(lam=S.lam, slope_ratio=S.r, mse=round(best[0], 5), null_mse=round(null_mse, 5), gain_pct=round(best[3], 4))
pd.DataFrame(cv_rows).to_csv(OUT / "cv_grid.csv", index=False)

def ratings(coef, k):
    z = Z[k]
    out = coef.copy()
    out["R_hi"] = out.a + out.b * z["hi"]; out["R_mid"] = out.a + out.b * z["mid"]; out["lift"] = out.R_hi - out.R_mid
    return out

for k, S in R.items():
    coef, mdl, _ = S.fit(S.lam, S.r)
    S.rt = ratings(coef, k).loc[S.elig]
    S.rt["rank"] = S.rt.R_hi.rank(ascending=False, method="first").astype(int)
    log[f"global_pressure_slope_{k}"] = round(float(mdl.coef_[-1] * 30), 4)

# =============================================================== 10. bootstrap + split-half reliability
mids = bb.match_id.unique()
for k, S in R.items():
    boots = []
    for i in range(N_BOOT):
        wm = pd.Series(RNG.poisson(1.0, len(mids)).astype(float), index=mids)
        coef, _, _ = S.fit(S.lam, S.r, idx=np.arange(len(S.y)), w=pd.Series(S.grp).map(wm).values)
        rr = ratings(coef, k).loc[S.elig]
        boots.append(rr[["R_hi", "lift"]].assign(rank=rr.R_hi.rank(ascending=False, method="first")))
        if i % 20 == 0: print(k, "boot", i, flush=True)
    H = pd.concat([b.R_hi for b in boots], axis=1); RK = pd.concat([b["rank"] for b in boots], axis=1)
    L = pd.concat([b.lift for b in boots], axis=1)
    S.rt["R_hi_lo"], S.rt["R_hi_hi"], S.rt["R_hi_sd"] = H.quantile(0.05, axis=1), H.quantile(0.95, axis=1), H.std(axis=1)
    S.rt["lift_lo"], S.rt["lift_hi"] = L.quantile(0.05, axis=1), L.quantile(0.95, axis=1)
    S.rt["rank_p05"], S.rt["rank_p50"], S.rt["rank_p95"] = RK.quantile(0.05, axis=1).round(), RK.median(axis=1).round(), RK.quantile(0.95, axis=1).round()
    S.rt["top10_pct"] = ((RK <= 10).mean(axis=1) * 100).round(1)
    S.rt["p_positive"] = ((H > 0).mean(axis=1) * 100).round(1)

rel_rows = []
for k, S in R.items():
    rr, rs = [], []
    for sp in range(N_SPLIT):
        half = set(RNG.choice(mids, len(mids) // 2, replace=False)); inA = np.array([g_ in half for g_ in S.grp])
        ca, _, _ = S.fit(S.lam, S.r, idx=np.where(inA)[0]); cb, _, _ = S.fit(S.lam, S.r, idx=np.where(~inA)[0])
        ra, rb = ratings(ca, k).R_hi.reindex(S.elig), ratings(cb, k).R_hi.reindex(S.elig)
        rr.append(pearsonr(ra, rb)[0])
        # Sample-1-style comparator: raw mean run value on top-25% pressure balls in each half
        d = S.df[S.df.p]; ma = d[np.isin(d.match_id, list(half))].groupby(S.own).rv.mean().reindex(S.elig)
        mb = d[~np.isin(d.match_id, list(half))].groupby(S.own).rv.mean().reindex(S.elig)
        okm = ma.notna() & mb.notna(); rs.append(pearsonr(ma[okm], mb[okm])[0])
    sb = lambda x: 2 * x / (1 + x)
    log[f"reliability_{k}"] = dict(ridge_half=round(np.mean(rr), 3), ridge_full=round(sb(np.mean(rr)), 3),
                                   simple_half=round(np.mean(rs), 3), simple_full=round(sb(np.mean(rs)), 3))
    for nm, v in (("Ridge clutch rating (Sample 2)", np.mean(rr)), ("Raw pressure run value (Sample 1 style)", np.mean(rs))):
        rel_rows.append(dict(key=f"{k}-{nm[:5]}", side="Batting" if k == "bat" else "Bowling", method=nm,
                             split_half=round(v, 3), full_sample=round(sb(v), 3)))
pd.DataFrame(rel_rows).to_csv(OUT / "reliability.csv", index=False)

# =============================================================== outputs
team_name = teams.drop_duplicates("team_id").set_index("team_id").team_name
def team_of(df, pid, tcol):
    t = df.groupby([pid, df.comp_type.eq("IPL"), tcol]).size().reset_index(name="n").sort_values("n", ascending=False)
    t.columns = [pid, "is_ipl", "tid", "n"]; out = {}
    for p, d in t.groupby(pid):
        intl, ipl = d[~d.is_ipl], d[d.is_ipl]
        out[p] = team_name.get(intl.tid.iloc[0]) if len(intl) else (team_name.get(ipl.tid.iloc[0]) if len(ipl) else "")
    return out

s1 = {}
if S1 is not None:
    for k, f in (("bat", "batting_rankings.csv"), ("bowl", "bowling_rankings.csv")):
        if (S1 / f).exists(): s1[k] = pd.read_csv(S1 / f).set_index("id")["rank"]

for k, S in R.items():
    d = S.df; own = S.own
    name = d.groupby(own)[("striker_name" if k == "bat" else "bowler_name")].agg(lambda s: s.value_counts().index[0])
    tm = team_of(d, own, "batting_team_id" if k == "bat" else "bowling_team_id")
    rows = []
    for pid, r in S.rt.sort_values("rank").iterrows():
        g_ = d[d[own] == pid]; P, N = g_[g_.p], g_[~g_.p]
        base = dict(rank=int(r["rank"]), id=int(pid), name=name[pid], team=tm.get(pid, ""),
                    balls=int(g_.faced.sum() if k == "bat" else g_.legal.sum()), P_balls=int(P.faced.sum() if k == "bat" else P.legal.sum()),
                    clutch=round(r.R_hi * 100, 2), clutch_lo=round(r.R_hi_lo * 100, 2), clutch_hi=round(r.R_hi_hi * 100, 2),
                    normal=round(r.R_mid * 100, 2), lift=round(r.lift * 100, 2), lift_lo=round(r.lift_lo * 100, 2), lift_hi=round(r.lift_hi * 100, 2),
                    level_a=round(r.a * 100, 2), slope_b=round(r.b * 100, 2), p_positive=r.p_positive, top10_pct=r.top10_pct,
                    rank_p05=int(r.rank_p05), rank_p50=int(r.rank_p50), rank_p95=int(r.rank_p95),
                    sample1_rank=int(s1[k][pid]) if k in s1 and pid in s1[k].index else None)
        if k == "bat":
            base.update(P_sr=round(P.runs.sum() / max(len(P), 1) * 100, 1), NP_sr=round(N.runs.sum() / max(len(N), 1) * 100, 1),
                        P_avg=round(P.runs.sum() / P.batter_out.sum(), 1) if P.batter_out.sum() else None)
        else:
            base.update(P_econ=round(P.bowler_conc.sum() / max(P.legal.sum(), 1) * 6, 2), NP_econ=round(N.bowler_conc.sum() / max(N.legal.sum(), 1) * 6, 2),
                        P_wkts=int(P.bowler_wkt.sum()))
        rows.append(base)
    T = pd.DataFrame(rows); T.to_csv(OUT / ("batters.csv" if k == "bat" else "bowlers.csv"), index=False)
    # rating curve across pressure percentiles for the top 10
    qs = np.arange(5, 100, 5); zq = S.df.z.quantile(qs / 100).values
    curve = [dict(key=f"{int(p)}-{q}", id=int(p), name=name[p], rank=int(S.rt.loc[p, "rank"]), pct=int(q),
                  rating=round((S.rt.loc[p, "a"] + S.rt.loc[p, "b"] * z) * 100, 2))
             for p in S.rt[S.rt["rank"] <= 10].index for q, z in zip(qs, zq)]
    pd.DataFrame(curve).to_csv(OUT / ("curve_bat.csv" if k == "bat" else "curve_bowl.csv"), index=False)
    if k in s1:
        top2, top1 = set(S.rt[S.rt["rank"] <= 10].index), set(s1[k][s1[k] <= 10].index)
        common = S.rt.index.intersection(s1[k].index)
        log[f"vs_sample1_{k}"] = dict(top10_overlap=len(top2 & top1), spearman=round(spearmanr(S.rt.loc[common, "rank"], s1[k][common])[0], 3))
    log[f"eligible_{k}"] = int(len(S.elig))

summ = dict(balls_used=log["balls_used"], matches_used=log["matches_used"], eligible_bat=log["eligible_bat"], eligible_bowl=log["eligible_bowl"])
for k in ("bat", "bowl"):
    summ.update({f"lam_{k}": log[f"cv_{k}"]["lam"], f"ratio_{k}": log[f"cv_{k}"]["slope_ratio"], f"cvgain_{k}": log[f"cv_{k}"]["gain_pct"],
                 f"rel_ridge_{k}": log[f"reliability_{k}"]["ridge_full"], f"rel_simple_{k}": log[f"reliability_{k}"]["simple_full"],
                 f"overlap_{k}": log.get(f"vs_sample1_{k}", {}).get("top10_overlap"), f"rho_s1_{k}": log.get(f"vs_sample1_{k}", {}).get("spearman"),
                 f"slope_{k}": log[f"global_pressure_slope_{k}"]})
pd.DataFrame([summ]).to_csv(OUT / "summary.csv", index=False)
(OUT / "summary.json").write_text(json.dumps(log, indent=1, default=str), encoding="utf-8")
print(json.dumps(log, default=str))
for f in ("batters.csv", "bowlers.csv"):
    print(pd.read_csv(OUT / f).head(15).to_string(index=False))
