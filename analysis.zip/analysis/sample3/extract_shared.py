"""Copy the <style> and <script> blocks of the Sample 3 dashboard (index.html) into shared.html,
so the report page reuses the same charts and tables without duplicating code.
Usage: python extract_shared.py <index.html> <shared.html>"""
import re, sys
from pathlib import Path
src = Path(sys.argv[1]).read_text(encoding="utf-8")
blocks = re.findall(r"<style>.*?</style>|<script>.*?</script>", src, re.S)
Path(sys.argv[2]).write_text("\n".join(blocks), encoding="utf-8")
print(len(blocks), "blocks written")
