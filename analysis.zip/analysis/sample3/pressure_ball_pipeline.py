"""
SAMPLE 3 — Pressure-ball-only rating (P1 rules + P3 win-probability + P6 hybrid, B3 baseline, C fairness)
--------------------------------------------------------------------------------------------------------
Usage:  python pressure_ball_pipeline.py <data_dir> <out_dir> [<sample1_out> <sample2_out>]

Self-contained. Does not import or modify Sample 1 / Sample 2 code.

Principles
  * A ball is a PRESSURE BALL only if a named cricket situation (P1 rule) fires AND the match is still alive
    (P3 win-probability gate). Leverage (P3/P4) is one of the rules, so the hybrid (P6) catches both
    "obvious" and "model-detected" pressure.
  * Players are judged ONLY on what they did on pressure balls. No win-probability-added, no match result:
    a player is never credited for being on the winning side or blamed for teammates losing.
  * Batters: runs vs expected and wickets kept vs expected.   Bowlers: wickets vs expected and runs saved (economy).
    "Expected" = league average on pressure balls in the same innings / over / wickets / pace-spin / competition cell.
  * B3: pressure-ball quality (vs league) + change vs the player's own normal (non-pressure) level.
  * C:  minimum samples, Empirical-Bayes shrinkage, per-match consistency, associate/A-team opposition weighted 0.6,
        bootstrap rank intervals, split-half reliability, weight sensitivity.
"""
import sys, json, re
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.stats import spearmanr, pearsonr
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold

DATA, OUT = Path(sys.argv[1]), Path(sys.argv[2])
S1 = Path(sys.argv[3]) if len(sys.argv) > 3 else None
S2 = Path(sys.argv[4]) if len(sys.argv) > 4 else None
OUT.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(2026)
GATE = (0.03, 0.97)                       # win-prob band in which the match is "alive"
KO_W, ASSOC_W = 1.25, 0.6                 # ball weights: knockout boost, associate/A-team opposition discount
BAT_MIN_P, BAT_MIN_INN = 120, 12          # eligibility: pressure balls faced, pressure innings
BOWL_MIN_P, BOWL_MIN_INN = 150, 12        # pressure legal balls bowled, pressure spells
STINT = {"bat": 6, "bowl": 6}             # balls in pressure in one match to count as a pressure appearance
W = {"bat": dict(scoring=.30, survival=.20, delta=.20, consistency=.20, volume=.10),
     "bowl": dict(wickets=.30, economy=.30, delta=.15, consistency=.15, volume=.10)}
N_BOOT, N_SPLIT = 200, 8
FULL = {"India", "Australia", "England", "South Africa", "New Zealand", "Pakistan", "Sri Lanka", "West Indies",
        "Bangladesh", "Afghanistan", "Ireland", "Zimbabwe"}
log = {}

# ============================================================ 1. load + state
b1 = pd.read_csv(DATA / "ball_by_ball-1.csv")
b2 = pd.read_csv(DATA / "ball_by_ball-2.csv", header=None, names=b1.columns)
bb = pd.concat([b1, b2], ignore_index=True)
matches = pd.read_csv(DATA / "matches.csv"); comps = pd.read_csv(DATA / "competitions.csv"); teams = pd.read_csv(DATA / "teams.csv")
team_name = teams.drop_duplicates("team_id").set_index("team_id").team_name
m = matches.merge(comps[["comp_id", "comp_name", "match_format"]], on="comp_id", how="left")
m["comp_type"] = np.where(m.comp_name.str.contains("IPL", na=False), "IPL", np.where(m.match_format.eq("T20I"), "T20I", "Other T20"))
m["reduced"] = m[["first_inn_revised_overs", "second_inn_revised_overs", "revised_target"]].notna().any(axis=1)
m["has_winner"] = m.win_team_id.notna() & (m.win_team_id > 0)
m["is_ko"] = (m.knock_out.eq(1) | m.stage.isin(["Final", "Qualifier", "Eliminator", "Semi Final"])).astype(int)
m["year"] = m.match_date.str[:4].astype(int)
mm = m.result.astype(str).str.extract(r"by (\d+)\s*(run|wicket|wkt)", flags=re.I)
m["margin_n"] = pd.to_numeric(mm[0], errors="coerce")

bb = bb[bb.innings.isin([1, 2])]
bb = bb[bb.match_id.isin(m.loc[(~m.reduced) & m.has_winner, "match_id"])].copy()
bb = bb.merge(m[["match_id", "comp_type", "year", "is_ko", "win_team_id"]], on="match_id", how="left")
bb = bb.sort_values(["match_id", "innings", "innings_ball_num"]).reset_index(drop=True)
et = bb.extras_type.fillna("None"); e2 = bb.extras_2_runs.fillna(0)
bb["is_wide"] = et.eq("wide"); bb["is_nb"] = et.eq("Overstep")
bb["legal"] = ~(bb.is_wide | bb.is_nb); bb["faced"] = ~bb.is_wide
extra = np.select([bb.is_wide | bb.is_nb, et.isin(["byes", "legbyes"]), et.eq("Penalty")], [1 + e2, np.maximum(1, e2), 5 + e2], default=e2)
bb["team_runs"] = bb.runs + extra
bb["bowler_conc"] = bb.runs + np.where(bb.is_wide | bb.is_nb, 1 + e2, 0)
bb["wkt"] = bb.is_wicket.astype(bool)
bb["batter_out"] = bb.wkt & (bb.dismissed_player_id.eq(bb.striker_id) | (bb.dismissed_player_id.isna() & ~bb.dismissal_type.eq("RunOut")))
bb["bowler_wkt"] = bb.wkt & bb.dismissal_type.isin(["Caught", "Bowled", "LBW", "Stump", "Hit Wicket"])
bb["phase"] = pd.cut(bb.overid, [0, 6, 15, 20], labels=["PP", "Middle", "Death"]).astype(str)
g = bb.groupby(["match_id", "innings"], sort=False)
bb["score_b"] = g.team_runs.cumsum() - bb.team_runs; bb["wk_b"] = g.wkt.cumsum() - bb.wkt; bb["lb_b"] = g.legal.cumsum() - bb.legal

tot = bb.groupby(["match_id", "innings"]).team_runs.sum().unstack()
tg = pd.DataFrame({"inn1": tot[1], "inn2": tot[2], "bat2": bb[bb.innings == 2].groupby("match_id").batting_team_id.first()}).dropna(subset=["inn1"])
tg = tg.join(m.set_index("match_id")[["win_team_id", "margin_n"]]); tg["target"] = tg.inn1 + 1
cw = tg.win_team_id.eq(tg.bat2); fa = cw & (tg.inn2 < tg.target); fb = (~cw) & tg.inn2.notna() & (tg.inn2 >= tg.target)
tg.loc[fa, "target"] = tg.loc[fa, "inn2"]; tg.loc[fb, "target"] = tg.loc[fb, "inn2"] + tg.loc[fb, "margin_n"].fillna(0).clip(lower=0) + 1
bb = bb.merge(tg[["target"]], left_on="match_id", right_index=True, how="left")
bb = bb[bb.target.notna()].reset_index(drop=True)
bb["bat_won"] = bb.win_team_id.eq(bb.batting_team_id).astype(int); bb["ipl"] = bb.comp_type.eq("IPL").astype(int)
log["balls_used"] = int(len(bb)); log["matches_used"] = int(bb.match_id.nunique())

# ============================================================ 2. win-probability (used ONLY to describe the situation)
HGB = dict(max_iter=200, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=1500, l2_regularization=5.0, random_state=42)
def _logit(p): p = np.clip(p, 1e-4, 1 - 1e-4); return np.log(p / (1 - p)).reshape(-1, 1)
def f1(score, wk, lb, ipl): lb = np.where(wk >= 10, 120, lb); return np.column_stack([score, wk, lb, score * 6 / np.maximum(lb, 1), ipl])
def f2(need, bl, wih, target, ipl): return np.column_stack([need, bl, wih, np.clip(need * 6 / np.maximum(bl, 1), 0, 36), target, ipl])
def fit_wp(X, y, grp, mono):
    oof = np.zeros(len(y))
    for tr, te in GroupKFold(5).split(X, y, grp):
        oof[te] = HistGradientBoostingClassifier(monotonic_cst=mono, **HGB).fit(X[tr], y[tr]).predict_proba(X[te])[:, 1]
    platt = LogisticRegression().fit(_logit(oof), y); full = HistGradientBoostingClassifier(monotonic_cst=mono, **HGB).fit(X, y)
    return lambda Xn: platt.predict_proba(_logit(full.predict_proba(Xn)[:, 1]))[:, 1]
i1 = bb[bb.innings == 1]
t1 = i1.groupby("match_id").agg(score=("team_runs", "sum"), wk=("wkt", "sum"), ipl=("ipl", "first"), y=("bat_won", "first"))
M1 = fit_wp(np.vstack([f1(i1.score_b, i1.wk_b, i1.lb_b, i1.ipl), f1(t1.score, t1.wk, np.full(len(t1), 120), t1.ipl)]),
            np.concatenate([i1.bat_won, t1.y]), np.concatenate([i1.match_id, t1.index]), [1, -1, -1, 1, 0])
i2 = bb[bb.innings == 2]; need = i2.target - i2.score_b; bl = 120 - i2.lb_b; wih = 10 - i2.wk_b; ok = (need > 0) & (bl > 0) & (wih > 0)
M2 = fit_wp(f2(need[ok], bl[ok], wih[ok], i2.target[ok], i2.ipl[ok]), i2.bat_won[ok].values, i2.match_id[ok].values, [-1, 1, 1, -1, 0, 0])
def wp2(need, bl, wih, target, ipl):
    need, bl, wih = (np.asarray(v, float) for v in (need, bl, wih)); out = np.full(len(need), np.nan)
    won = need <= 0; tie = (need == 1) & ((bl <= 0) | (wih <= 0)); lost = ~won & ~tie & ((bl <= 0) | (wih <= 0))
    out[won], out[tie], out[lost] = 1.0, 0.5, 0.0; live = np.isnan(out)
    if live.any(): out[live] = M2(f2(need[live], bl[live], wih[live], np.asarray(target)[live], np.asarray(ipl)[live]))
    return out
def wp_state(df, dr, dw, db):
    res = np.zeros(len(df)); a = (df.innings == 1).values; d = df[a]
    res[a] = M1(f1(d.score_b + dr, np.minimum(d.wk_b + dw, 10), np.minimum(d.lb_b + db, 120), d.ipl)); d = df[~a]
    res[~a] = wp2(d.target - d.score_b - dr, 120 - d.lb_b - db, 10 - d.wk_b - dw, d.target, d.ipl); return res
bb["wp"] = wp_state(bb, 0, 0, 0)
bb["oc"] = np.where(bb.is_wide | bb.is_nb, "X", np.where(bb.wkt, "W", bb.team_runs.clip(upper=6).replace({5: 4}).astype(int).astype(str)))
probs = bb.groupby(["innings", "phase"]).oc.value_counts(normalize=True).unstack(fill_value=0)
lev = np.zeros(len(bb)); pk = pd.MultiIndex.from_arrays([bb.innings, bb.phase])
for oc, (dr, dw, db) in {"0": (0, 0, 1), "1": (1, 0, 1), "2": (2, 0, 1), "3": (3, 0, 1), "4": (4, 0, 1), "6": (6, 0, 1), "W": (0, 1, 1), "X": (1, 0, 0)}.items():
    lev += probs[oc].reindex(pk).values * np.abs(wp_state(bb, dr, dw, db) - bb.wp.values)
bb["LI"] = lev / lev.mean()

# ============================================================ 3. situation variables + P1 rules
w12 = np.zeros(len(bb)); r18 = np.zeros(len(bb))
for _, idx in bb.groupby(["match_id", "innings"], sort=False).indices.items():
    L = bb.lb_b.values[idx]
    j12 = np.searchsorted(L, L - 12, side="left"); j18 = np.searchsorted(L, L - 18, side="left")
    w12[idx] = bb.wk_b.values[idx] - bb.wk_b.values[idx][j12]; r18[idx] = bb.score_b.values[idx] - bb.score_b.values[idx][j18]
bb["w12"], bb["r18"] = w12, r18
bb["since_wkt"] = bb.lb_b - bb.groupby(["match_id", "innings", "wk_b"]).lb_b.transform("min")
inn2 = bb.innings.eq(2)
bb["need"] = np.where(inn2, bb.target - bb.score_b, np.nan)
bb["balls_left"] = 120 - bb.lb_b
bb["rrr"] = np.where(inn2, bb.need * 6 / bb.balls_left.clip(lower=1), np.nan)
bb["crr"] = bb.score_b * 6 / bb.lb_b.clip(lower=1)
li90 = bb.LI.quantile(0.90)
close = bb.wp.between(0.25, 0.75)
alive = bb.wp.between(*GATE) & (~inn2 | (bb.need > 0))

BAT_RULES = {
    "Steep chase (RRR ≥ 9, last 12 overs)": inn2 & (bb.rrr >= 9) & (bb.balls_left <= 72),
    "Big target (180+) with 3+ wickets down": inn2 & (bb.target >= 180) & (bb.wk_b >= 3),
    "Early collapse (3 down in 8 ov / 5 down in 15)": ((bb.wk_b >= 3) & (bb.lb_b < 48)) | ((bb.wk_b >= 5) & (bb.lb_b < 90)),
    "Wickets tumbling (2+ in last 2 overs)": bb.w12 >= 2,
    "Tight finish (overs 16-20, win prob 25-75%)": (bb.overid >= 16) & close,
    "High leverage (top 10% of balls)": bb.LI >= li90,
}
BOWL_RULES = {
    "Defending a close chase (overs 14-20)": inn2 & (bb.overid >= 14) & bb.wp.between(0.2, 0.8),
    "Under attack (36+ conceded in last 3 overs)": (bb.r18 >= 36) & (bb.lb_b >= 18),
    "Big total building (overs 15-20, ≤4 down, RR ≥ 8.5)": bb.innings.eq(1) & (bb.overid >= 15) & (bb.wk_b <= 4) & (bb.crr >= 8.5),
    "Breakthrough needed (36+ balls no wicket, RR ≥ 8.5)": (bb.since_wkt >= 36) & (bb.crr >= 8.5),
    "Tight finish (overs 16-20, win prob 25-75%)": (bb.overid >= 16) & close,
    "High leverage (top 10% of balls)": bb.LI >= li90,
}
bb["bat_p"] = alive & np.logical_or.reduce([v.values for v in BAT_RULES.values()])
bb["bowl_p"] = alive & np.logical_or.reduce([v.values for v in BOWL_RULES.values()])
bb["bat_nrules"] = sum(v.astype(int) for v in BAT_RULES.values()) * alive
bb["bowl_nrules"] = sum(v.astype(int) for v in BOWL_RULES.values()) * alive

# fairness weights (C): opposition strength proxy + knockout
bat_team = bb.batting_team_id.map(team_name).fillna(""); bowl_team = bb.bowling_team_id.map(team_name).fillna("")
weak = lambda t: ~t.isin(FULL)
non_ipl = bb.comp_type.ne("IPL")
bb["w_bat"] = np.where(non_ipl & weak(bowl_team), ASSOC_W, 1.0) * np.where(bb.is_ko.eq(1), KO_W, 1.0)
bb["w_bowl"] = np.where(non_ipl & weak(bat_team), ASSOC_W, 1.0) * np.where(bb.is_ko.eq(1), KO_W, 1.0)

# ============================================================ 4. expected outcomes (separately for pressure / normal balls)
bb["wb"] = pd.cut(bb.wk_b, [-1, 1, 3, 5, 10], labels=["0-1", "2-3", "4-5", "6+"]).astype(str)
FINE = ["innings", "phase", "overid", "wb", "pace_or_spin", "comp_type"]; COARSE = ["innings", "phase", "wb"]
def smooth_mean(df, val, k=40):
    c = df.groupby(COARSE)[val].mean().rename("c").reset_index()
    gm = df[val].mean()
    f = df.groupby(FINE)[val].agg(["sum", "count"]).reset_index().merge(c, on=COARSE, how="left")
    f["c"] = f.c.fillna(gm); f["m"] = (f["sum"] + k * f["c"]) / (f["count"] + k)
    return df[FINE].merge(f[FINE + ["m"]], on=FINE, how="left")["m"].fillna(gm).values
def expected_by_regime(df, flag, val):
    out = np.zeros(len(df))
    for v in (True, False):
        s = df[flag] == v; out[s.values] = smooth_mean(df[s], val)
    return out

i1 = bb[bb.innings == 1]; rem = (i1.groupby("match_id").team_runs.transform("sum") - i1.score_b)
u_all, w_all, r_all = (120 - i1.lb_b).values, i1.wk_b.values, rem.values
RE = np.zeros((121, 11))
for wq in range(10):
    sel = w_all >= wq if wq >= 7 else w_all == wq
    (a, c), _ = curve_fit(lambda u, a, c: a * (1 - np.exp(-c * u)), u_all[sel], r_all[sel], p0=[200, 0.01], bounds=([0, 1e-5], [600, 1]))
    RE[:, wq] = a * (1 - np.exp(-c * (120 - np.arange(121))))
RE = np.minimum.accumulate(RE, axis=1); WC = np.clip(RE[:, :-1] - RE[:, 1:], 0, None)
bb["wc"] = WC[np.clip(bb.lb_b, 0, 119).astype(int), np.clip(bb.wk_b, 0, 9).astype(int)]

bat = bb[bb.faced].copy().reset_index(drop=True)
bat["xr"] = expected_by_regime(bat, "bat_p", "runs"); bat["xo"] = expected_by_regime(bat, "bat_p", "batter_out")
bat["c1"] = bat.runs - bat.xr                                   # scoring: runs above expected
bat["c2"] = bat.xo - bat.batter_out.astype(float)               # survival: dismissals avoided vs expected
bat["rv"] = bat.c1 + bat.wc * bat.c2                            # one run-value number, wicket priced in runs
bat["p"], bat["w"], bat["n"] = bat.bat_p, bat.w_bat, 1.0
bat["isdot"] = (bat.runs == 0) & ~bat.batter_out; bat["bdry"] = bat.runs >= 4

bowl = bb.copy().reset_index(drop=True)
bowl["xc"] = expected_by_regime(bowl, "bowl_p", "bowler_conc"); bowl["xw"] = expected_by_regime(bowl, "bowl_p", "bowler_wkt")
bowl["c1"] = bowl.bowler_wkt.astype(float) - bowl.xw           # wickets above expected
bowl["c2"] = bowl.xc - bowl.bowler_conc                         # runs saved vs expected (economy)
bowl["rv"] = bowl.c2 + bowl.wc * bowl.c1
bowl["p"], bowl["w"], bowl["n"] = bowl.bowl_p, bowl.w_bowl, bowl.legal.astype(float)
bowl["isdot"] = bowl.legal & (bowl.bowler_conc == 0); bowl["bdry"] = bowl.runs >= 4

# ============================================================ 5. pressure-definition evidence
def rule_rows(df, rules, side, base_flag):
    rows = []
    for nm, mask in rules.items():
        mk = (mask.reindex(df.index) if False else None)
    return rows
rule_out = []
for side, rules, df, flag in (("Batting", BAT_RULES, bat, "bat_p"), ("Bowling", BOWL_RULES, bowl, "bowl_p")):
    keep = bb.faced if side == "Batting" else pd.Series(True, index=bb.index)
    alive_k = alive[keep].values
    for i, (nm, mask) in enumerate(rules.items()):
        mk = mask[keep].values & alive_k
        d = df[mk]
        r = dict(key=f"{side}-{i}", side=side, rule=nm, share=round(mk.mean() * 100, 1), balls=int(mk.sum()),
                 only_rule=round(((df[("bat_nrules" if side == "Batting" else "bowl_nrules")] == 1) & mk).sum() / max(mk.sum(), 1) * 100, 1))
        if side == "Batting":
            r.update(sr=round(d.runs.sum() / max(len(d), 1) * 100, 1), out_pct=round(d.batter_out.mean() * 100, 2))
        else:
            r.update(econ=round(d.bowler_conc.sum() / max(d.legal.sum(), 1) * 6, 2), wkt_pct=round(d.bowler_wkt.sum() / max(d.legal.sum(), 1) * 100, 2))
        rule_out.append(r)
pd.DataFrame(rule_out).to_csv(OUT / "rules.csv", index=False)

lg = []
for side, df in (("Batting", bat), ("Bowling", bowl)):
    for lab, d in (("Pressure balls", df[df.p]), ("Normal balls", df[~df.p])):
        r = dict(key=f"{side}-{lab}", side=side, regime=lab, share=round(len(d) / len(df) * 100, 1), balls=int(len(d)),
                 mean_LI=round(d.LI.mean(), 2), wp_close=round(d.wp.between(0.25, 0.75).mean() * 100, 1))
        if side == "Batting":
            r.update(sr=round(d.runs.sum() / len(d) * 100, 1), out_pct=round(d.batter_out.mean() * 100, 2),
                     dot_pct=round(d.isdot.mean() * 100, 1), bdry_pct=round(d.bdry.mean() * 100, 1))
        else:
            lgl = d.legal.sum()
            r.update(econ=round(d.bowler_conc.sum() / lgl * 6, 2), wkt_pct=round(d.bowler_wkt.sum() / lgl * 100, 2),
                     dot_pct=round(d.isdot.sum() / lgl * 100, 1), bdry_pct=round(d.bdry.sum() / lgl * 100, 1))
        lg.append(r)
pd.DataFrame(lg).to_csv(OUT / "league.csv", index=False)
log["pressure_share"] = dict(bat=round(bat.p.mean() * 100, 1), bowl=round(bowl.p.mean() * 100, 1))
log["dead_balls_removed_pct"] = round((~alive).mean() * 100, 1)

# ============================================================ 6. player-match table + scoring
def pm_table(df, pid):
    d = df.assign(wn=df.w * df.n, w1=df.w * df.c1, w2=df.w * df.c2, wr=df.w * df.rv)
    gm = d.groupby([pid, "match_id", "p"]).agg(n=("wn", "sum"), raw=("n", "sum"), c1=("w1", "sum"), c2=("w2", "sum"), rv=("wr", "sum")).reset_index()
    return gm

def aggregate(gm, pid, wm=None):
    if wm is not None:
        f = gm.match_id.map(wm).values
        gm = gm.assign(n=gm.n * f, c1=gm.c1 * f, c2=gm.c2 * f, rv=gm.rv * f, raw_w=f)
    else:
        gm = gm.assign(raw_w=1.0)
    P = gm[gm.p].groupby(pid).agg(Pn=("n", "sum"), Pc1=("c1", "sum"), Pc2=("c2", "sum"), Prv=("rv", "sum"))
    N = gm[~gm.p].groupby(pid).agg(Nn=("n", "sum"), Nrv=("rv", "sum"))
    st = gm[gm.p & (gm.raw >= 6)]
    C = st.assign(s=(st.rv > 0) * st.raw_w).groupby(pid).agg(Cn=("raw_w", "sum"), Cs=("s", "sum"))
    return P.join(N, how="outer").join(C, how="left").fillna(0)

def eb_k(sm, n, s2, cap=(150, 1000)):   # bounded prior strength (balls): stops both under- and over-shrinking
    mean = sm / n; tau2 = np.var(mean) - np.mean(s2 / n)
    k = s2 / tau2 if tau2 > 1e-12 else cap[1]
    return float(np.clip(k, *cap))

def beta_k(s, n, cap=(5, 40)):
    p = s / n; mu = s.sum() / n.sum(); tau2 = np.var(p) - np.mean(mu * (1 - mu) / n)
    k = (mu * (1 - mu) / tau2 - 1) if tau2 > 1e-9 else cap[1]
    return float(np.clip(k, *cap))

def score(A, elig, K, side, wts=None):
    wts = wts or W[side]; A = A.reindex(elig).fillna(0); o = pd.DataFrame(index=A.index)
    for col, n in (("Pc1", "Pn"), ("Pc2", "Pn"), ("Prv", "Pn"), ("Nrv", "Nn")):
        mu = A[col].sum() / A[n].sum(); o[col] = (A[col] + K[col] * mu) / (A[n] + K[col])
    mu = A.Cs.sum() / max(A.Cn.sum(), 1e-9); o["cons"] = (A.Cs + K["cons"] * mu) / (A.Cn + K["cons"])
    o["delta"] = o.Prv - o.Nrv; o["vol"] = np.log1p(A.Pn)
    z = lambda s: (s - s.mean()) / s.std(ddof=0)
    names = ("scoring", "survival") if side == "bat" else ("wickets", "economy")
    o[f"z_{names[0]}"] = z(o.Pc1); o[f"z_{names[1]}"] = z(o.Pc2)
    o["z_delta"], o["z_consistency"], o["z_volume"] = z(o.delta), z(o.cons), z(o.vol)
    o["score"] = sum(wts[k] * o[f"z_{k}"] for k in wts)
    for k in wts: o[f"pts_{k}"] = wts[k] * o[f"z_{k}"]
    o["rank"] = o.score.rank(ascending=False, method="first").astype(int)
    return o

R = {}
for side, df, pid, nmin, imin in (("bat", bat, "striker_id", BAT_MIN_P, BAT_MIN_INN), ("bowl", bowl, "bowler_id", BOWL_MIN_P, BOWL_MIN_INN)):
    gm = pm_table(df, pid); A = aggregate(gm, pid)
    raw_p = gm[gm.p].groupby(pid).agg(rawP=("raw", "sum"), inns=("match_id", "nunique"))
    elig = raw_p.index[(raw_p.rawP >= nmin) & (raw_p.inns >= imin)]
    Ae = A.loc[elig]; K = {}
    for col, n, regime, comp in (("Pc1", "Pn", True, "c1"), ("Pc2", "Pn", True, "c2"), ("Prv", "Pn", True, "rv"), ("Nrv", "Nn", False, "rv")):
        s2 = df[(df.p == regime) & df[pid].isin(elig) & (df.n > 0)][comp].var()
        K[col] = eb_k(Ae[col].values, Ae[n].values, s2)
    ce = Ae[Ae.Cn > 0]; K["cons"] = beta_k(ce.Cs.values, ce.Cn.values)
    S = score(A, elig, K, side)
    R[side] = dict(df=df, pid=pid, gm=gm, A=A, elig=elig, K=K, S=S, raw_p=raw_p)
    log[f"eligible_{side}"] = int(len(elig)); log[f"k_{side}"] = {a: round(b, 1) for a, b in K.items()}
    print(side, "eligible", len(elig), "k", log[f"k_{side}"], flush=True)

# ============================================================ 7. bootstrap, split-half reliability, sensitivity
mids = bb.match_id.unique()
for side, r in R.items():
    ranks = []
    for b in range(N_BOOT):
        wm = pd.Series(RNG.poisson(1.0, len(mids)).astype(float), index=mids)
        ranks.append(score(aggregate(r["gm"], r["pid"], wm), r["elig"], r["K"], side)["rank"])
    Rk = pd.concat(ranks, axis=1)
    r["S"]["rank_p05"] = Rk.quantile(0.05, axis=1).round().astype(int); r["S"]["rank_p50"] = Rk.median(axis=1).round().astype(int)
    r["S"]["rank_p95"] = Rk.quantile(0.95, axis=1).round().astype(int); r["S"]["top10_pct"] = ((Rk <= 10).mean(axis=1) * 100).round(1)
    rel, rel_raw = [], []
    for sp in range(N_SPLIT):
        half = pd.Series(RNG.random(len(mids)) < 0.5, index=mids)
        sa = score(aggregate(r["gm"], r["pid"], half.astype(float)), r["elig"], r["K"], side).score
        sb = score(aggregate(r["gm"], r["pid"], (~half).astype(float)), r["elig"], r["K"], side).score
        rel.append(pearsonr(sa, sb)[0])
    sbf = lambda x: 2 * x / (1 + x)
    log[f"reliability_{side}"] = dict(split_half=round(float(np.mean(rel)), 3), full=round(float(sbf(np.mean(rel))), 3))

ALT = {"bat": {"Equal weights": dict(scoring=.2, survival=.2, delta=.2, consistency=.2, volume=.2),
               "Pressure balls only (no delta vs normal)": dict(scoring=.40, survival=.30, delta=0, consistency=.20, volume=.10),
               "Scoring-heavy": dict(scoring=.45, survival=.15, delta=.15, consistency=.15, volume=.10),
               "Survival-heavy": dict(scoring=.20, survival=.40, delta=.15, consistency=.15, volume=.10)},
       "bowl": {"Equal weights": dict(wickets=.2, economy=.2, delta=.2, consistency=.2, volume=.2),
                "Pressure balls only (no delta vs normal)": dict(wickets=.35, economy=.35, delta=0, consistency=.20, volume=.10),
                "Wicket-heavy": dict(wickets=.45, economy=.20, delta=.15, consistency=.10, volume=.10),
                "Economy-heavy": dict(wickets=.20, economy=.45, delta=.15, consistency=.10, volume=.10)}}
sens = []
for side, r in R.items():
    top = set(r["S"].nsmallest(10, "rank").index)
    for nm, wts in ALT[side].items():
        s = score(r["A"], r["elig"], r["K"], side, wts)
        sens.append(dict(key=f"{side}-{nm}", side="Batting" if side == "bat" else "Bowling", variant=nm,
                         top10_overlap=len(top & set(s.nsmallest(10, "rank").index)), spearman=round(spearmanr(r["S"]["rank"], s["rank"].reindex(r["S"].index))[0], 3)))
pd.DataFrame(sens).to_csv(OUT / "sensitivity.csv", index=False)

# ============================================================ 8. player tables
other = {}
for tag, path in (("s1", S1), ("s2", S2)):
    if path is None: continue
    for side, f, col in (("bat", "batting_rankings.csv", "id"), ("bowl", "bowling_rankings.csv", "id")):
        fp = path / f if (path / f).exists() else path / ("batters.csv" if side == "bat" else "bowlers.csv")
        if fp.exists():
            t = pd.read_csv(fp); other[(tag, side)] = t.set_index("id")["rank"]

def team_of(df, pid, tcol):
    t = df.groupby([pid, df.comp_type.eq("IPL"), tcol]).size().reset_index(name="cnt").sort_values("cnt", ascending=False)
    t.columns = [pid, "is_ipl", "tid", "cnt"]; out = {}
    for p, d in t.groupby(pid):
        intl, ipl = d[~d.is_ipl], d[d.is_ipl]
        out[p] = team_name.get(intl.tid.iloc[0]) if len(intl) else (team_name.get(ipl.tid.iloc[0]) if len(ipl) else "")
    return out

for side, r in R.items():
    df, pid, S = r["df"], r["pid"], r["S"]
    nm = df.groupby(pid)["striker_name" if side == "bat" else "bowler_name"].agg(lambda s: s.value_counts().index[0])
    tm = team_of(df, pid, "batting_team_id" if side == "bat" else "bowling_team_id")
    rows = []
    for p, s in S.sort_values("rank").iterrows():
        d = df[df[pid] == p]; P, N = d[d.p], d[~d.p]
        row = dict(rank=int(s["rank"]), id=int(p), name=nm[p], team=tm.get(p, ""), P_inns=int(P.match_id.nunique()),
                   score=round(s.score, 3), rank_p05=int(s.rank_p05), rank_p50=int(s.rank_p50), rank_p95=int(s.rank_p95), top10_pct=s.top10_pct,
                   prv100=round(s.Prv * 100, 2), nrv100=round(s.Nrv * 100, 2), delta100=round(s.delta * 100, 2), cons=round(s.cons * 100, 1),
                   **{k: round(float(s[k]), 3) for k in s.index if k.startswith("pts_")},
                   s1_rank=int(other[("s1", side)][p]) if ("s1", side) in other and p in other[("s1", side)].index else None,
                   s2_rank=int(other[("s2", side)][p]) if ("s2", side) in other and p in other[("s2", side)].index else None)
        if side == "bat":
            po, no = int(P.batter_out.sum()), int(N.batter_out.sum())
            row.update(P_balls=int(len(P)), P_runs=int(P.runs.sum()), P_outs=po, P_sr=round(P.runs.sum() / len(P) * 100, 1),
                       NP_sr=round(N.runs.sum() / max(len(N), 1) * 100, 1), P_avg=round(P.runs.sum() / po, 1) if po else None,
                       NP_avg=round(N.runs.sum() / no, 1) if no else None, P_bpd=round(len(P) / po, 1) if po else None,
                       NP_bpd=round(len(N) / no, 1) if no else None, P_dot=round(P.isdot.mean() * 100, 1), P_bdry=round(P.bdry.mean() * 100, 1),
                       scoring100=round(s.Pc1 * 100, 2), survival100=round(s.Pc2 * 100, 2))
        else:
            lp, ln = int(P.legal.sum()), int(N.legal.sum()); wp_, wn_ = int(P.bowler_wkt.sum()), int(N.bowler_wkt.sum())
            row.update(P_balls=lp, P_wkts=wp_, P_runs=int(P.bowler_conc.sum()), P_econ=round(P.bowler_conc.sum() / lp * 6, 2),
                       NP_econ=round(N.bowler_conc.sum() / max(ln, 1) * 6, 2), P_sr=round(lp / wp_, 1) if wp_ else None,
                       NP_sr=round(ln / wn_, 1) if wn_ else None, P_dot=round(P.isdot.sum() / lp * 100, 1), P_bdry=round(P.bdry.sum() / lp * 100, 1),
                       wickets100=round(s.Pc1 * 100, 2), economy100=round(s.Pc2 * 100, 2))
        rows.append(row)
    T = pd.DataFrame(rows)
    T.to_csv(OUT / ("batters.csv" if side == "bat" else "bowlers.csv"), index=False)
    for tag in ("s1", "s2"):
        if (tag, side) in other:
            o = other[(tag, side)]; com = T.id[T.id.isin(o.index)]
            log[f"vs_{tag}_{side}"] = dict(top10_overlap=int(len(set(T.id[T["rank"] <= 10]) & set(o[o <= 10].index))),
                                         spearman=round(spearmanr(T.set_index("id").loc[com, "rank"], o[com])[0], 3))

summ = dict(balls_used=log["balls_used"], matches_used=log["matches_used"], eligible_bat=log["eligible_bat"], eligible_bowl=log["eligible_bowl"],
            pshare_bat=log["pressure_share"]["bat"], pshare_bowl=log["pressure_share"]["bowl"], dead_pct=log["dead_balls_removed_pct"],
            rel_bat=log["reliability_bat"]["full"], rel_bowl=log["reliability_bowl"]["full"],
            **{f"{a}_{t}_{s}": log.get(f"vs_{t}_{s}", {}).get(b) for t in ("s1", "s2") for s in ("bat", "bowl") for a, b in (("ov", "top10_overlap"), ("rho", "spearman"))})
pd.DataFrame([summ]).to_csv(OUT / "summary.csv", index=False)
(OUT / "summary.json").write_text(json.dumps(log, indent=1, default=str), encoding="utf-8")
print(json.dumps(log, default=str))
pd.set_option("display.width", 250)
print(pd.read_csv(OUT / "batters.csv")[["rank", "name", "team", "P_balls", "P_sr", "NP_sr", "P_avg", "P_bpd", "scoring100", "survival100", "delta100", "cons", "top10_pct", "s1_rank", "s2_rank"]].head(15).to_string(index=False))
print(pd.read_csv(OUT / "bowlers.csv")[["rank", "name", "team", "P_balls", "P_wkts", "P_econ", "NP_econ", "P_sr", "wickets100", "economy100", "delta100", "cons", "top10_pct", "s1_rank", "s2_rank"]].head(15).to_string(index=False))
