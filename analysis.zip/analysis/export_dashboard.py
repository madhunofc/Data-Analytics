"""Turn pipeline outputs into the small CSVs the dashboard reads.  Usage: python export_dashboard.py <pipeline_out_dir>"""
import sys, json
from pathlib import Path
import pandas as pd

OUT = Path(sys.argv[1]); D = OUT / "dash"; D.mkdir(exist_ok=True)
S = json.loads((OUT / "summary.json").read_text(encoding="utf-8"))

def team(r):
    return r["country"] if isinstance(r["country"], str) else (r["ipl_team"] if isinstance(r["ipl_team"], str) else "")

common = ["rank", "name", "team", "ipl_team", "P_balls", "matches_p", "ko_balls", "Prv_s", "NPrv_s", "delta", "Pwpa_s", "wpa",
          "cons_s", "impact", "score", "rank_p05", "rank_p50", "rank_p95", "top10_pct", "seasons_pos", "ipl_rv100", "intl_rv100"]
b = pd.read_csv(OUT / "batting_rankings.csv"); b["team"] = b.apply(team, axis=1)
b[common[:5] + ["P_runs", "P_outs", "P_sr", "NP_sr", "P_avg", "NP_avg", "P_dot", "NP_dot", "P_bdry", "NP_bdry"] + common[5:]] \
    .to_csv(D / "batters.csv", index=False)
w = pd.read_csv(OUT / "bowling_rankings.csv"); w["team"] = w.apply(team, axis=1)
w[common[:5] + ["type", "P_wkts", "P_econ", "NP_econ", "P_sr", "NP_sr", "P_dot", "NP_dot", "P_bdry", "NP_bdry"] + common[5:]] \
    .to_csv(D / "bowlers.csv", index=False)

rows = []
for side, key in (("Batting", "tiers_bat"), ("Bowling", "tiers_bowl")):
    for t in S[key]:
        rows.append(dict(key=f"{side}-{t['tier']}", side=side, **t))
pd.DataFrame(rows).to_csv(D / "tiers.csv", index=False)

li = pd.DataFrame(S["LI_by_over"]).rename(columns={"inn1": "li_inn1", "inn2": "li_inn2"})
ps = pd.DataFrame(S["pressure_share_by_over"]).rename(columns={"inn1": "pressure_pct_inn1", "inn2": "pressure_pct_inn2"})
li.merge(ps, on="over").to_csv(D / "by_over.csv", index=False)
pd.DataFrame(S["closeness"]).to_csv(D / "closeness.csv", index=False)

cal = [dict(key=f"{inn}-{i}", innings=lab, **c) for inn, lab in (("wp_inn1", "1st innings"), ("wp_inn2", "Chase"))
       for i, c in enumerate(S[inn]["calibration"])]
pd.DataFrame(cal).to_csv(D / "calibration.csv", index=False)

sens = [dict(key=f"{side}-{i}", side="Batting" if side == "bat" else "Bowling", **r)
        for side in ("bat", "bowl") for i, r in enumerate(S["sensitivity"][side])]
pd.DataFrame(sens).to_csv(D / "sensitivity.csv", index=False)

pd.DataFrame([dict(
    balls_used=S["balls_used"], matches_used=S["matches_used"], matches_dropped=S["matches_dropped_reduced_or_noresult"],
    raw_balls=S["raw_balls"], target_fixes=S["target_consistency_fixes"],
    eligible_bat=S["eligible_bat"], eligible_bowl=S["eligible_bowl"],
    auc_inn1=S["wp_inn1"]["auc"], ece_inn1=S["wp_inn1"]["ece"], brier_inn1=S["wp_inn1"]["brier"],
    auc_inn2=S["wp_inn2"]["auc"], ece_inn2=S["wp_inn2"]["ece"], brier_inn2=S["wp_inn2"]["brier"],
    threshold_bat=S["thresholds"]["bat"], threshold_bowl=S["thresholds"]["bowl"],
    split_bat_players=S["ipl_vs_intl"]["bat"]["players"], split_bat_rho=S["ipl_vs_intl"]["bat"]["spearman"],
    split_bowl_players=S["ipl_vs_intl"]["bowl"]["players"], split_bowl_rho=S["ipl_vs_intl"]["bowl"]["spearman"],
    k_bat_prv=S["shrinkage_k_bat"]["Prv"], k_bowl_prv=S["shrinkage_k_bowl"]["Prv"])]).to_csv(D / "summary.csv", index=False)
for f in sorted(D.iterdir()): print(f.name, f.stat().st_size)
