"""
Bundle a dashboard page + its CSVs into one standalone HTML file (opens offline except d3 from cdnjs).
Usage: python build_html.py <body.html> <csv_dir> <out.html> "<title>"
Every CSV in csv_dir is embedded as dataset id = file stem, served to the page through a tiny `dash` shim.
"""
import sys, csv, json
from pathlib import Path

body_path, csv_dir, out_path, title = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
data = {}
for f in sorted(csv_dir.glob("*.csv")):
    with f.open(encoding="utf-8") as fh:
        data[f.stem] = [{k: (v if v != "" else None) for k, v in row.items()} for row in csv.DictReader(fh)]
body_text = ""
for part in str(body_path).split("+"):          # "a.html+b.html" concatenates several body files in order
    body_text += Path(part).read_text(encoding="utf-8") + "\n"
body = "\n".join(l for l in body_text.splitlines() if 'name="dash-one-writer"' not in l)
embed = json.dumps(data, separators=(",", ":")).replace("</", "<\\/")

HEAD = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<style>
  /* Layout: single centred column, cards on a lightly tinted ground. Palette: pitch green + leather amber. */
  :root {
    --color-bg: #f6f8f5; --color-panel: #ffffff; --color-fg: #17201b; --color-fg-muted: #5b6760;
    --color-border-line: #dde4de; --color-ok: #1f8a4c; --color-bad: #c0392b; --color-warn: #b7791f;
    --cx-s0: #0f7b5f; --cx-s1: #c8841a;
    --cds-chart-muted: #a7b2ab; --cds-chart-grid: #e6ebe7; --cds-chart-axis: #c7d0ca; --cds-chart-reference: #9aa6a0;
    --cds-text-secondary: #5b6760; --cds-surface-popover: #ffffff; --cds-border: #d3dbd5;
    --cds-shadow-popover: 0 6px 24px rgba(16, 32, 24, .12);
    --font-anthropic-sans: "Inter", "Segoe UI", system-ui, -apple-system, sans-serif;
    --font-anthropic-serif: "Source Serif 4", Georgia, "Times New Roman", serif;
    --cds-font-size-caption: 12.5px; --cds-font-size-body: 14.5px; --cds-font-size-heading: 19px; --cds-font-size-title: 30px;
    --cds-font-weight-medium: 600;
    --cds-gap-xs: 4px; --cds-gap-sm: 8px; --cds-gap-md: 14px; --cds-gap-lg: 20px; --cds-gap-xl: 36px;
    --cds-pad-xs: 4px; --cds-pad-sm: 8px; --cds-pad-md: 12px; --cds-pad-lg: 18px; --cds-pad-xl: 28px;
    --cds-radius: 10px;
  }
  @media (prefers-color-scheme: dark) {
    :root:not([data-theme="light"]) {
      --color-bg: #101512; --color-panel: #171e1a; --color-fg: #e7ede9; --color-fg-muted: #9aa8a0;
      --color-border-line: #26302a; --color-ok: #4cc27f; --color-bad: #ef6f62; --color-warn: #e0a84a;
      --cx-s0: #3cc39a; --cx-s1: #e6a443;
      --cds-chart-muted: #56635b; --cds-chart-grid: #222b25; --cds-chart-axis: #33403a; --cds-chart-reference: #6c7a72;
      --cds-text-secondary: #9aa8a0; --cds-surface-popover: #1d2520; --cds-border: #2e3a33;
      --cds-shadow-popover: 0 6px 24px rgba(0, 0, 0, .5); color-scheme: dark;
    }
  }
  :root[data-theme="dark"] {
    --color-bg: #101512; --color-panel: #171e1a; --color-fg: #e7ede9; --color-fg-muted: #9aa8a0;
    --color-border-line: #26302a; --color-ok: #4cc27f; --color-bad: #ef6f62; --color-warn: #e0a84a;
    --cx-s0: #3cc39a; --cx-s1: #e6a443;
    --cds-chart-muted: #56635b; --cds-chart-grid: #222b25; --cds-chart-axis: #33403a; --cds-chart-reference: #6c7a72;
    --cds-text-secondary: #9aa8a0; --cds-surface-popover: #1d2520; --cds-border: #2e3a33;
    --cds-shadow-popover: 0 6px 24px rgba(0, 0, 0, .5); color-scheme: dark;
  }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--color-bg); color: var(--color-fg); font: 14.5px/1.5 var(--font-anthropic-sans); }
  #dash-root { max-width: 1180px; margin: 0 auto; padding-block: 32px 56px;
    padding-left: max(16px, env(safe-area-inset-left, 0px)); padding-right: max(16px, env(safe-area-inset-right, 0px)); }
  .dash-select { appearance: none; font: inherit; color: var(--color-fg); background-color: var(--color-panel);
    border: 1px solid var(--color-border-line); border-radius: 8px; padding: 6px 30px 6px 10px; cursor: pointer;
    background-image: linear-gradient(45deg, transparent 50%, currentColor 50%), linear-gradient(135deg, currentColor 50%, transparent 50%);
    background-position: calc(100% - 15px) 55%, calc(100% - 10px) 55%; background-size: 5px 5px; background-repeat: no-repeat; }
  .dash-select:focus-visible { outline: 2px solid var(--cx-s0); outline-offset: 2px; }
  .cx-footer { margin-top: 40px; color: var(--color-fg-muted); font-size: 12.5px; }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.9.0/d3.min.js"></script>
<script>
window.EMBED = __EMBED__;
window.dash = (() => {
  const draws = {};
  const run = (name) => document.querySelectorAll(`[data-draw="${name}"]`).forEach((el) => {
    try { draws[name](el); } catch (e) { console.error(name, e); }
  });
  return {
    colors: ['var(--cx-s0)', 'var(--cx-s1)', 'var(--color-warn)', 'var(--cds-chart-muted)'],
    data(id) {
      const rows = window.EMBED[id];
      return rows ? { status: 'ok', data: rows } : { status: 'missing', data: [] };
    },
    draw(name, fn) { if (fn) draws[name] = fn; else if (draws[name]) run(name); },
    runAll() { Object.keys(draws).forEach(run); },
    onData(fn) { fn(); }, params: () => ({}), setParams() {}, setLink() {}
  };
})();
</script>
</head>
<body>
<div id="dash-root">
"""
TAIL = """
<p class="cx-footer">Standalone export. Data embedded from <code>__SRC__</code>. Charts need d3 from cdnjs, so open it with an internet connection.</p>
</div>
<script>
(() => {
  const go = () => window.dash.runAll();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
  let t; let lastW = window.innerWidth;
  window.addEventListener('resize', () => {
    if (window.innerWidth === lastW) return;
    lastW = window.innerWidth; clearTimeout(t); t = setTimeout(go, 150);
  });
})();
</script>
</body>
</html>
"""
html = HEAD.replace("__TITLE__", title).replace("__EMBED__", embed) + body + TAIL.replace("__SRC__", csv_dir.as_posix())
out_path.write_text(html, encoding="utf-8")
print(out_path, len(html), "bytes;", ", ".join(f"{k}={len(v)}" for k, v in data.items()))
