"""
Clutch / Pressure Performance Pipeline  (P6 hybrid pressure + Pipeline 2 + B3 baseline)
------------------------------------------------------------------------------------
Usage:  python pressure_pipeline.py <data_dir> <out_dir>

Steps
 1. Load + clean ball-by-ball (part 2 has no header), drop super overs, reduced-overs (DLS) and no-result matches.
 2. Reconstruct match state (score, wickets, legal balls) and an estimated chase target.
 3. Win-probability models (1st and 2nd innings) - monotonic gradient boosting, validated out-of-fold by match.
 4. Leverage Index (expected |WP swing| of the next ball) -> P6 hybrid pressure score with explicit flags
    (knockout match, batting collapse, bowler under attack).
 5. Context-expected outcomes (xRuns, xOut, xWicket) + run-expectancy wicket cost -> Run Value per ball.
 6. Player metrics in pressure vs non-pressure (B3: absolute pressure quality + delta vs own baseline),
    Empirical-Bayes shrinkage, per-match consistency, composite score.
 7. Bootstrap (resample matches) for rank stability; sensitivity to weights and pressure threshold;
    IPL vs T20I split check.
"""
import sys, json, re
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score, brier_score_loss, log_loss
from scipy.stats import spearmanr

DATA, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(42)
PRESSURE_Q = 0.75                      # top 25% of balls by pressure score = "pressure ball"
WEIGHTS = dict(impact=0.40, delta=0.25, consistency=0.20, volume=0.15)
BAT_MIN_BALLS, BAT_MIN_PBALLS = 300, 100
BOWL_MIN_BALLS, BOWL_MIN_PBALLS = 360, 120
MIN_PRESSURE_STINT = 6                 # balls in pressure in a match to count as a "pressure appearance"
N_BOOT = 300
log = {}

# ------------------------------------------------------------------ 1. load
b1 = pd.read_csv(DATA / "ball_by_ball-1.csv")
b2 = pd.read_csv(DATA / "ball_by_ball-2.csv", header=None, names=b1.columns)
bb = pd.concat([b1, b2], ignore_index=True)
matches = pd.read_csv(DATA / "matches.csv")
comps = pd.read_csv(DATA / "competitions.csv")
teams = pd.read_csv(DATA / "teams.csv")
log["raw_balls"] = len(bb); log["raw_matches_with_balls"] = bb.match_id.nunique()

m = matches.merge(comps[["comp_id", "comp_name", "match_format", "season"]], on="comp_id", how="left")
m["comp_type"] = np.where(m.comp_name.str.contains("IPL", na=False), "IPL",
                  np.where(m.match_format.eq("T20I"), "T20I", "Other T20"))
m["reduced"] = m[["first_inn_revised_overs", "second_inn_revised_overs", "revised_target"]].notna().any(axis=1)
m["has_winner"] = m.win_team_id.notna() & (m.win_team_id > 0)
m["is_ko"] = (m.knock_out.eq(1) | m.stage.isin(["Final", "Qualifier", "Eliminator", "Semi Final"])).astype(int)
m["year"] = m.match_date.str[:4].astype(int)

def margin(res):
    r = re.search(r"by (\d+)\s*(run|wicket|wkt)", str(res), re.I)
    if not r: return (np.nan, "super_over" if "eliminator" in str(res).lower() or "super over" in str(res).lower() else None)
    return (int(r.group(1)), "runs" if r.group(2).lower().startswith("run") else "wkts")
mm = m.result.apply(margin)
m["margin_n"] = [x[0] for x in mm]; m["margin_type"] = [x[1] for x in mm]

bb = bb[bb.innings.isin([1, 2])]
log["super_over_balls_dropped"] = int(log["raw_balls"] - len(bb))
valid = m[(~m.reduced) & m.has_winner][["match_id"]]
dropped = set(bb.match_id) - set(valid.match_id)
log["matches_dropped_reduced_or_noresult"] = len(dropped)
bb = bb[bb.match_id.isin(valid.match_id)].copy()
bb = bb.merge(m[["match_id", "comp_type", "comp_name", "season", "year", "is_ko", "win_team_id", "stage"]], on="match_id", how="left")
bb = bb.sort_values(["match_id", "innings", "innings_ball_num"]).reset_index(drop=True)
log["balls_used"] = len(bb); log["matches_used"] = bb.match_id.nunique()

# ------------------------------------------------------------------ 2. ball fields + state
et = bb.extras_type.fillna("None")
e2 = bb.extras_2_runs.fillna(0)
bb["is_wide"] = et.eq("wide"); bb["is_nb"] = et.eq("Overstep")
bb["legal"] = ~(bb.is_wide | bb.is_nb)
bb["faced"] = ~bb.is_wide
extra = np.select([bb.is_wide | bb.is_nb, et.isin(["byes", "legbyes"]), et.eq("Penalty")],
                  [1 + e2, np.maximum(1, e2), 5 + e2], default=e2)
bb["team_runs"] = bb.runs + extra
bb["bowler_conc"] = bb.runs + np.where(bb.is_wide | bb.is_nb, 1 + e2, 0)
bb["wkt"] = bb.is_wicket.astype(bool)
bb["batter_out"] = bb.wkt & (bb.dismissed_player_id.eq(bb.striker_id) |
                             (bb.dismissed_player_id.isna() & ~bb.dismissal_type.eq("RunOut")))
bb["bowler_wkt"] = bb.wkt & bb.dismissal_type.isin(["Caught", "Bowled", "LBW", "Stump", "Hit Wicket"])
bb["phase"] = pd.cut(bb.overid, [0, 6, 15, 20], labels=["PP", "Middle", "Death"]).astype(str)

g = bb.groupby(["match_id", "innings"], sort=False)
bb["score_b"] = g.team_runs.cumsum() - bb.team_runs
bb["wk_b"] = g.wkt.cumsum() - bb.wkt
bb["lb_b"] = g.legal.cumsum() - bb.legal
bb["score_a"] = bb.score_b + bb.team_runs
bb["wk_a"] = bb.wk_b + bb.wkt
bb["lb_a"] = bb.lb_b + bb.legal

tot = bb.groupby(["match_id", "innings"]).team_runs.sum().unstack()
bat1 = bb[bb.innings == 1].groupby("match_id").batting_team_id.first()
bat2 = bb[bb.innings == 2].groupby("match_id").batting_team_id.first()
tg = pd.DataFrame({"inn1": tot[1], "inn2": tot[2], "bat2": bat2}).dropna(subset=["inn1"])
tg = tg.join(m.set_index("match_id")[["win_team_id", "margin_n", "margin_type"]])
tg["target"] = tg.inn1 + 1
chase_won = tg.win_team_id.eq(tg.bat2)
fix_a = chase_won & (tg.inn2 < tg.target)
fix_b = (~chase_won) & tg.inn2.notna() & (tg.inn2 >= tg.target)
tg.loc[fix_a, "target"] = tg.loc[fix_a, "inn2"]
tg.loc[fix_b, "target"] = tg.loc[fix_b, "inn2"] + tg.loc[fix_b, "margin_n"].fillna(0).clip(lower=0) + 1
log["target_consistency_fixes"] = int(fix_a.sum() + fix_b.sum()); log["innings_pairs"] = int(len(tg))
bb = bb.merge(tg[["target"]], left_on="match_id", right_index=True, how="left")
bb["bat_won"] = bb.win_team_id.eq(bb.batting_team_id).astype(int)
bb["ipl"] = bb.comp_type.eq("IPL").astype(int)

# ------------------------------------------------------------------ 3. win probability models
def hgb():
    # strong regularisation: balls inside one match share a label, so small leaves overfit
    return dict(max_iter=200, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=1500,
                l2_regularization=5.0, random_state=42)

from sklearn.linear_model import LogisticRegression
def _logit(p): p = np.clip(p, 1e-4, 1 - 1e-4); return np.log(p / (1 - p)).reshape(-1, 1)

def f1(score, wk, lb, ipl):
    lb = np.where(wk >= 10, 120, lb)
    return np.column_stack([score, wk, lb, score * 6 / np.maximum(lb, 1), ipl])

def f2(need, bl, wih, target, ipl):
    return np.column_stack([need, bl, wih, np.clip(need * 6 / np.maximum(bl, 1), 0, 36), target, ipl])

i1 = bb[bb.innings == 1]
term1 = i1.groupby("match_id").agg(score=("score_a", "last"), wk=("wk_a", "last"), ipl=("ipl", "first"), y=("bat_won", "first"))
X1 = np.vstack([f1(i1.score_b, i1.wk_b, i1.lb_b, i1.ipl), f1(term1.score, term1.wk, np.full(len(term1), 120), term1.ipl)])
y1 = np.concatenate([i1.bat_won, term1.y]); grp1 = np.concatenate([i1.match_id, term1.index])
mono1 = [1, -1, -1, 1, 0]

i2 = bb[(bb.innings == 2) & bb.target.notna()]
need = i2.target - i2.score_b; bl = 120 - i2.lb_b; wih = 10 - i2.wk_b
ok = (need > 0) & (bl > 0) & (wih > 0)
X2 = f2(need[ok], bl[ok], wih[ok], i2.target[ok], i2.ipl[ok]); y2 = i2.bat_won[ok].values; grp2 = i2.match_id[ok].values
mono2 = [-1, 1, 1, -1, 0, 0]

def cv_eval(X, y, grp, mono, name):
    oof = np.zeros(len(y))
    for tr, te in GroupKFold(5).split(X, y, grp):
        mdl = HistGradientBoostingClassifier(monotonic_cst=mono, **hgb()).fit(X[tr], y[tr])
        oof[te] = mdl.predict_proba(X[te])[:, 1]
    platt = LogisticRegression().fit(_logit(oof), y)           # Platt scaling learned on out-of-fold predictions
    # honest post-calibration check: cross-fit the calibrator by match too
    oof_c = np.zeros(len(y))
    for tr, te in GroupKFold(5).split(X, y, grp):
        oof_c[te] = LogisticRegression().fit(_logit(oof[tr]), y[tr]).predict_proba(_logit(oof[te]))[:, 1]
    bins = pd.cut(oof_c, np.linspace(0, 1, 11), include_lowest=True)
    cal = pd.DataFrame({"p": oof_c, "y": y, "b": bins}).groupby("b", observed=True).agg(pred=("p", "mean"), actual=("y", "mean"), n=("y", "size"))
    log[f"wp_{name}"] = dict(auc=round(roc_auc_score(y, oof_c), 3), brier=round(brier_score_loss(y, oof_c), 3),
                            logloss=round(log_loss(y, oof_c), 3), brier_uncalibrated=round(brier_score_loss(y, oof), 3),
                            ece=round(float((cal.n * (cal.pred - cal.actual).abs()).sum() / cal.n.sum()), 3), n=int(len(y)),
                            matches=int(len(np.unique(grp))),
                            calibration=[dict(pred=round(r.pred, 3), actual=round(r.actual, 3), n=int(r.n)) for r in cal.itertuples()])
    full = HistGradientBoostingClassifier(monotonic_cst=mono, **hgb()).fit(X, y)
    return lambda Xn: platt.predict_proba(_logit(full.predict_proba(Xn)[:, 1]))[:, 1]

M1 = cv_eval(X1, y1, grp1, mono1, "inn1")
M2 = cv_eval(X2, y2, grp2, mono2, "inn2")

def wp1(score, wk, lb, ipl):
    return M1(f1(score, wk, lb, ipl))

def wp2(need, bl, wih, target, ipl):
    need, bl, wih = np.asarray(need, float), np.asarray(bl, float), np.asarray(wih, float)
    out = np.full(len(need), np.nan)
    won = need <= 0; tie = (need == 1) & ((bl <= 0) | (wih <= 0)); lost = ~won & ~tie & ((bl <= 0) | (wih <= 0))
    out[won], out[tie], out[lost] = 1.0, 0.5, 0.0
    live = np.isnan(out)
    if live.any():
        out[live] = M2(f2(need[live], bl[live], wih[live], np.asarray(target)[live], np.asarray(ipl)[live]))
    return out

def wp_state(df, dr, dw, db):
    """WP of batting side after adding dr runs, dw wickets, db legal balls to the pre-ball state."""
    res = np.zeros(len(df))
    a = (df.innings == 1).values
    d = df[a]
    res[a] = wp1(d.score_b + dr, np.minimum(d.wk_b + dw, 10), np.minimum(d.lb_b + db, 120), d.ipl)
    d = df[~a]
    res[~a] = wp2(d.target - d.score_b - dr, 120 - d.lb_b - db, 10 - d.wk_b - dw, d.target, d.ipl)
    return res

bb = bb[bb.target.notna()].reset_index(drop=True)
bb["wp_b"] = wp_state(bb, 0, 0, 0)
a1 = bb.innings == 1
bb["wp_a"] = 0.0
bb.loc[a1, "wp_a"] = wp1(bb.score_a[a1], bb.wk_a[a1], bb.lb_a[a1], bb.ipl[a1])
bb.loc[~a1, "wp_a"] = wp2(bb.target[~a1] - bb.score_a[~a1], 120 - bb.lb_a[~a1], 10 - bb.wk_a[~a1], bb.target[~a1], bb.ipl[~a1])
bb["wpa"] = bb.wp_a - bb.wp_b          # batting-side win probability added

# ------------------------------------------------------------------ 4. leverage + pressure
def outcome(r):
    if r.is_wide or r.is_nb: return "X"
    if r.wkt: return "W"
    return str(min(int(r.team_runs), 6) if r.team_runs != 5 else 4)
bb["oc"] = np.where(bb.is_wide | bb.is_nb, "X", np.where(bb.wkt, "W",
                    bb.team_runs.clip(upper=6).replace({5: 4}).astype(int).astype(str)))
probs = bb.groupby(["innings", "phase"]).oc.value_counts(normalize=True).unstack(fill_value=0)
OUTC = {"0": (0, 0, 1), "1": (1, 0, 1), "2": (2, 0, 1), "3": (3, 0, 1), "4": (4, 0, 1), "6": (6, 0, 1), "W": (0, 1, 1), "X": (1, 0, 0)}
lev = np.zeros(len(bb))
pk = pd.MultiIndex.from_arrays([bb.innings, bb.phase])
for oc, (dr, dw, db) in OUTC.items():
    p = probs[oc].reindex(pk).values if oc in probs else 0
    lev += p * np.abs(wp_state(bb, dr, dw, db) - bb.wp_b.values)
bb["LI"] = lev / lev.mean()

# rolling context: wickets & runs in previous 18 legal balls of the innings
w18 = np.zeros(len(bb)); r18 = np.zeros(len(bb))
for _, idx in bb.groupby(["match_id", "innings"], sort=False).indices.items():
    L = bb.lb_b.values[idx]; W = bb.wk_b.values[idx]; S = bb.score_b.values[idx]
    j = np.searchsorted(L, L - 18, side="left")
    w18[idx] = W - W[j]; r18[idx] = S - S[j]
bb["w18"], bb["r18"] = w18, r18
bb["flag_ko"] = bb.is_ko.eq(1)
bb["flag_collapse"] = bb.w18 >= 2                         # batting side lost 2+ wkts in last 3 overs
bb["flag_attack"] = (bb.r18 >= 30) & (bb.lb_b >= 18)      # bowling side conceded 30+ in last 3 overs
ko = np.where(bb.flag_ko, 1.25, 1.0)
bb["bat_ps"] = bb.LI * ko * np.where(bb.flag_collapse, 1.2, 1.0)
bb["bowl_ps"] = bb.LI * ko * np.where(bb.flag_attack, 1.2, 1.0)

def tier(ps, cuts):
    return pd.cut(ps, [-np.inf, cuts[0], cuts[1], cuts[2], np.inf], labels=["Low", "Medium", "High", "Extreme"]).astype(str)
bat_cuts = bb.bat_ps.quantile([0.5, PRESSURE_Q, 0.9]).values
bowl_cuts = bb.bowl_ps.quantile([0.5, PRESSURE_Q, 0.9]).values
bb["bat_tier"] = tier(bb.bat_ps, bat_cuts); bb["bowl_tier"] = tier(bb.bowl_ps, bowl_cuts)

# ------------------------------------------------------------------ 5. expected outcomes + run value
bb["wb"] = pd.cut(bb.wk_b, [-1, 1, 3, 5, 10], labels=["0-1", "2-3", "4-5", "6+"]).astype(str)
FINE = ["innings", "phase", "overid", "wb", "pace_or_spin", "comp_type"]   # phase is implied by overid
COARSE = ["innings", "phase", "wb"]; COARSE = ["innings", "phase", "wb"]

def smooth_mean(df, val, k=40):
    c = df.groupby(COARSE)[val].mean().rename("c").reset_index()
    f = df.groupby(FINE)[val].agg(["sum", "count"]).reset_index().merge(c, on=COARSE)
    f["m"] = (f["sum"] + k * f["c"]) / (f["count"] + k)
    return df[FINE].merge(f[FINE + ["m"]], on=FINE, how="left")["m"].values

i1 = bb[bb.innings == 1]
rem = (i1.groupby("match_id").team_runs.transform("sum") - i1.score_b)
# DLS-style resource curve per wickets lost:  E[remaining runs | balls left u, wkts w] = a_w * (1 - exp(-c_w * u))
from scipy.optimize import curve_fit
u_all = (120 - i1.lb_b).values; w_all = i1.wk_b.values; r_all = rem.values
RE = np.zeros((121, 11)); re_params = {}
for w in range(10):
    sel = w_all >= w if w >= 7 else w_all == w                 # pool sparse late-wicket states
    (a, c), _ = curve_fit(lambda u, a, c: a * (1 - np.exp(-c * u)), u_all[sel], r_all[sel], p0=[200, 0.01],
                          bounds=([0, 1e-5], [600, 1]))
    re_params[w] = (round(a, 1), round(c, 4))
    RE[:, w] = a * (1 - np.exp(-c * (120 - np.arange(121))))
RE = np.minimum.accumulate(RE, axis=1)                          # more wickets down never means more runs to come
log["run_expectancy_params"] = re_params
WC = np.clip(RE[:, :-1] - RE[:, 1:], 0, None)          # runs a wicket costs at (balls bowled, wkts down)
bb["wc"] = WC[np.clip(bb.lb_b, 0, 119).astype(int), np.clip(bb.wk_b, 0, 9).astype(int)]
log["wicket_cost_examples"] = {f"over{o+1}_w{w}": round(float(WC[o * 6, w]), 1) for o in (0, 9, 16) for w in (0, 3, 6)}

bat = bb[bb.faced].copy()
bat["xr"] = smooth_mean(bat, "runs"); bat["xo"] = smooth_mean(bat, "batter_out")
bat["rv"] = (bat.runs - bat.xr) - bat.wc * (bat.batter_out.astype(float) - bat.xo)
bat["p"] = bat.bat_ps >= bat_cuts[1]
bat["isdot"] = (bat.runs == 0) & ~bat.batter_out; bat["bdry"] = bat.runs >= 4

bowl = bb.copy()
bowl["xc"] = smooth_mean(bowl, "bowler_conc"); bowl["xw"] = smooth_mean(bowl, "bowler_wkt")
bowl["rv"] = (bowl.xc - bowl.bowler_conc) + bowl.wc * (bowl.bowler_wkt.astype(float) - bowl.xw)
bowl["wpa_b"] = -bowl.wpa
bowl["p"] = bowl.bowl_ps >= bowl_cuts[1]
bowl["isdot"] = bowl.legal & (bowl.bowler_conc == 0); bowl["bdry"] = bowl.runs >= 4

# ------------------------------------------------------------------ pressure-definition validation
def league(df, tcol, kind):
    rows = []
    for t in ["Low", "Medium", "High", "Extreme"]:
        d = df[df[tcol] == t]
        r = dict(tier=t, balls=int(len(d)), share=round(len(d) / len(df) * 100, 1), mean_LI=round(d.LI.mean(), 2),
                 mean_abs_wpa=round(d.wpa.abs().mean() * 100, 2),
                 death_share=round((d.phase == "Death").mean() * 100, 1), chase_share=round((d.innings == 2).mean() * 100, 1),
                 ko_share=round(d.flag_ko.mean() * 100, 1))
        if kind == "bat":
            r.update(sr=round(d.runs.sum() / len(d) * 100, 1), out_pct=round(d.batter_out.mean() * 100, 2),
                     dot_pct=round(d.isdot.mean() * 100, 1), bdry_pct=round(d.bdry.mean() * 100, 1))
        else:
            lg = d.legal.sum()
            r.update(econ=round(d.bowler_conc.sum() / lg * 6, 2), wkt_pct=round(d.bowler_wkt.sum() / lg * 100, 2),
                     dot_pct=round(d.isdot.sum() / lg * 100, 1))
        rows.append(r)
    return rows
log["tiers_bat"] = league(bat, "bat_tier", "bat"); log["tiers_bowl"] = league(bowl, "bowl_tier", "bowl")
log["thresholds"] = dict(bat=round(float(bat_cuts[1]), 3), bowl=round(float(bowl_cuts[1]), 3))
log["LI_by_over"] = [dict(over=int(o), inn1=round(float(a), 2), inn2=round(float(b), 2)) for o, a, b in
                     bb.groupby(["overid", "innings"]).LI.mean().unstack().reset_index().itertuples(index=False)]
log["pressure_share_by_over"] = [dict(over=int(o), inn1=round(float(a) * 100, 1), inn2=round(float(b) * 100, 1)) for o, a, b in
                                 bat.groupby(["overid", "innings"]).p.mean().unstack().reset_index().itertuples(index=False)]
mli = bb.groupby("match_id").agg(LI=("LI", "mean"), ptime=("bat_ps", lambda s: (s >= bat_cuts[1]).mean()))
mli = mli.join(m.set_index("match_id")[["margin_n", "margin_type"]])
def close_band(r):
    if r.margin_type == "super_over": return "Tie / super over"
    if r.margin_type == "runs": return "≤10 runs" if r.margin_n <= 10 else ("11-25 runs" if r.margin_n <= 25 else ">25 runs")
    if r.margin_type == "wkts": return "≤3 wkts" if r.margin_n <= 3 else ("4-6 wkts" if r.margin_n <= 6 else "7+ wkts")
    return None
mli["band"] = mli.apply(close_band, axis=1)
order = ["Tie / super over", "≤10 runs", "≤3 wkts", "11-25 runs", "4-6 wkts", ">25 runs", "7+ wkts"]
cb = mli.groupby("band").agg(matches=("LI", "size"), mean_LI=("LI", "mean"), pressure_pct=("ptime", "mean")).reindex(order).dropna()
log["closeness"] = [dict(band=b, matches=int(r.matches), mean_LI=round(r.mean_LI, 2), pressure_pct=round(r.pressure_pct * 100, 1)) for b, r in cb.iterrows()]
log["comp_mix"] = {k: dict(balls=int(v), pressure_pct=round(bat[bat.comp_type == k].p.mean() * 100, 1)) for k, v in bat.comp_type.value_counts().items()}

# ------------------------------------------------------------------ 6. player metrics
names_bat = bat.groupby("striker_id").striker_name.agg(lambda s: s.value_counts().index[0])
names_bowl = bowl.groupby("bowler_id").bowler_name.agg(lambda s: s.value_counts().index[0])
team_name = teams.drop_duplicates("team_id").set_index("team_id").team_name
def teams_of(df, pid_col, team_col):
    t = df.groupby([pid_col, "comp_type", team_col]).size().reset_index(name="n")
    t["team"] = t[team_col].map(team_name)
    out = {}
    for pid, d in t.groupby(pid_col):
        intl = d[d.comp_type != "IPL"].sort_values("n", ascending=False)
        ipl = d[d.comp_type == "IPL"].sort_values("n", ascending=False)
        out[pid] = dict(country=intl.team.iloc[0] if len(intl) else None, ipl=ipl.team.iloc[0] if len(ipl) else None)
    return out
teams_bat = teams_of(bat, "striker_id", "batting_team_id"); teams_bowl = teams_of(bowl, "bowler_id", "bowling_team_id")

def player_match(df, pid, pcol, wpa_col, n_col):
    d = df.assign(n=df[n_col].astype(float), pp=df[pcol])
    gm = d.groupby([pid, "match_id", "pp"]).agg(n=("n", "sum"), rv=("rv", "sum"), wpa=(wpa_col, "sum")).reset_index()
    return gm

def eb_k(sum_, n, s2):
    mean = sum_ / n
    tau2 = np.var(mean) - np.mean(s2 / n)
    return s2 / tau2 if tau2 > 1e-12 else 1e6

def beta_k(s, n):
    p = s / n; mu = s.sum() / n.sum()
    tau2 = np.var(p) - np.mean(mu * (1 - mu) / n)
    return (mu * (1 - mu) / tau2 - 1) if tau2 > 1e-9 else 1e4

def aggregate(gm, pid, w=None):
    gm = gm if w is None else gm.assign(n=gm.n * gm.match_id.map(w), rv=gm.rv * gm.match_id.map(w), wpa=gm.wpa * gm.match_id.map(w),
                                         wt=gm.match_id.map(w))
    if "wt" not in gm: gm = gm.assign(wt=1.0)
    P = gm[gm.pp].groupby(pid).agg(Pn=("n", "sum"), Prv=("rv", "sum"), Pwpa=("wpa", "sum"))
    NP = gm[~gm.pp].groupby(pid).agg(NPn=("n", "sum"), NPrv=("rv", "sum"))
    st = gm[gm.pp & (gm.n / gm.wt.replace(0, np.nan) >= MIN_PRESSURE_STINT)]
    C = st.assign(s=(st.rv > 0) * st.wt).groupby(pid).agg(Cn=("wt", "sum"), Cs=("s", "sum"))
    return P.join(NP, how="outer").join(C, how="left").fillna(0)

def score(A, elig, K, w=WEIGHTS):
    A = A.reindex(elig).fillna(0)
    out = pd.DataFrame(index=A.index)
    for col, n, k in [("Prv", "Pn", K["Prv"]), ("Pwpa", "Pn", K["Pwpa"]), ("NPrv", "NPn", K["NPrv"])]:
        mu = A[col].sum() / A[n].sum()
        out[col + "_s"] = (A[col] + k * mu) / (A[n] + k)
    mu = A.Cs.sum() / max(A.Cn.sum(), 1e-9)
    out["cons_s"] = (A.Cs + K["cons"] * mu) / (A.Cn + K["cons"])
    z = lambda s: (s - s.mean()) / s.std(ddof=0)
    out["impact"] = 0.5 * z(out.Prv_s) + 0.5 * z(out.Pwpa_s)
    out["delta"] = out.Prv_s - out.NPrv_s
    out["volume"] = np.log1p(A.Pn)
    out["score"] = (w["impact"] * z(out.impact) + w["delta"] * z(out.delta) +
                    w["consistency"] * z(out.cons_s) + w["volume"] * z(out.volume))
    out["rank"] = out.score.rank(ascending=False, method="first").astype(int)
    return out

def run_side(df, kind, pressure_col_override=None):
    if kind == "bat":
        pid, wcol, ncol, min_b, min_p = "striker_id", "wpa", "faced", BAT_MIN_BALLS, BAT_MIN_PBALLS
    else:
        pid, wcol, ncol, min_b, min_p = "bowler_id", "wpa_b", "legal", BOWL_MIN_BALLS, BOWL_MIN_PBALLS
    pcol = pressure_col_override or "p"
    gm = player_match(df, pid, pcol, wcol, ncol)
    A = aggregate(gm, pid)
    elig = A.index[(A.Pn + A.NPn >= min_b) & (A.Pn >= min_p)]
    Ae = A.loc[elig]
    s2 = {}
    for col, n in [("Prv", "Pn"), ("Pwpa", "Pn"), ("NPrv", "NPn")]:
        src = df[df[pcol] if col.startswith("P") else ~df[pcol]]
        src = src[src[pid].isin(elig)]
        val = src["rv"] if "rv" in col else src[wcol]
        s2[col] = val.var()
    K = {c: eb_k(Ae[c].values, Ae[n].values, s2[c]) for c, n in [("Prv", "Pn"), ("Pwpa", "Pn"), ("NPrv", "NPn")]}
    ce = Ae[Ae.Cn > 0]
    K["cons"] = beta_k(ce.Cs.values, ce.Cn.values)
    # Method-of-moments can return ~infinite k when between-player spread is buried in noise;
    # cap at a weakly-informative prior so the component still ranks rather than collapsing.
    K["mom_raw"] = dict(K)
    K["Prv"], K["NPrv"] = min(K["Prv"], 1500), min(K["NPrv"], 1500)
    K["Pwpa"], K["cons"] = min(K["Pwpa"], 1500), min(K["cons"], 30)
    S = score(A, elig, K)
    return dict(gm=gm, A=A, elig=elig, K=K, S=S, pid=pid)

R = {"bat": run_side(bat, "bat"), "bowl": run_side(bowl, "bowl")}
for k in R:
    log[f"eligible_{k}"] = int(len(R[k]["elig"]))
    log[f"shrinkage_k_{k}"] = {a: round(float(b), 1) for a, b in R[k]["K"].items() if a != "mom_raw"}
    log[f"shrinkage_k_mom_{k}"] = {a: round(float(b), 1) for a, b in R[k]["K"]["mom_raw"].items()}

# ------------------------------------------------------------------ 7. bootstrap
mids = bb.match_id.unique()
for k, r in R.items():
    ranks = []
    for b in range(N_BOOT):
        w = pd.Series(RNG.poisson(1.0, len(mids)).astype(float), index=mids)
        A = aggregate(r["gm"], r["pid"], w)
        ranks.append(score(A, r["elig"], r["K"])["rank"])
    Rk = pd.concat(ranks, axis=1)
    r["S"]["rank_p05"] = Rk.quantile(0.05, axis=1).round().astype(int)
    r["S"]["rank_p50"] = Rk.median(axis=1).round().astype(int)
    r["S"]["rank_p95"] = Rk.quantile(0.95, axis=1).round().astype(int)
    r["S"]["top10_pct"] = ((Rk <= 10).mean(axis=1) * 100).round(1)

# ------------------------------------------------------------------ sensitivity
ALT = {"Equal weights": dict(impact=.25, delta=.25, consistency=.25, volume=.25),
       "Impact-heavy": dict(impact=.6, delta=.2, consistency=.1, volume=.1),
       "No volume term": dict(impact=.45, delta=.3, consistency=.25, volume=0)}
sens = {}
for k, r in R.items():
    base = r["S"]; top = set(base.nsmallest(10, "rank").index); rows = []
    for nm, w in ALT.items():
        s = score(r["A"], r["elig"], r["K"], w)
        rows.append(dict(variant=nm, top10_overlap=len(top & set(s.nsmallest(10, "rank").index)),
                         spearman=round(spearmanr(base["rank"], s["rank"].reindex(base.index))[0], 3)))
    df = bat if k == "bat" else bowl
    pscol = "bat_ps" if k == "bat" else "bowl_ps"
    for q in (0.70, 0.80):
        thr = df[pscol].quantile(q); df["p_alt"] = df[pscol] >= thr
        rr = run_side(df, k, "p_alt"); s = rr["S"]
        common = base.index.intersection(s.index)
        rows.append(dict(variant=f"Pressure = top {int(round((1-q)*100))}% of balls", top10_overlap=len(top & set(s.nsmallest(10, "rank").index)),
                         spearman=round(spearmanr(base["rank"].reindex(common), s["rank"].reindex(common))[0], 3)))
    sens[k] = rows
log["sensitivity"] = sens

# ------------------------------------------------------------------ IPL vs T20I split check
split = {}
for k, df, pid in [("bat", bat, "striker_id"), ("bowl", bowl, "bowler_id")]:
    n = "faced" if k == "bat" else "legal"
    d = df[df.p].assign(nn=lambda x: x[n].astype(float))
    t = d.groupby([pid, d.comp_type.eq("IPL").map({True: "IPL", False: "Intl"})]).agg(n=("nn", "sum"), rv=("rv", "sum")).unstack()
    t = t[(t[("n", "IPL")] >= 50) & (t[("n", "Intl")] >= 50)]
    a = t[("rv", "IPL")] / t[("n", "IPL")]; bq = t[("rv", "Intl")] / t[("n", "Intl")]
    split[k] = dict(players=int(len(t)), spearman=round(spearmanr(a, bq)[0], 3))
    R[k]["split"] = t
log["ipl_vs_intl"] = split

# ------------------------------------------------------------------ player tables
def bat_table(r):
    S = r["S"]; ids = S.index
    d = bat[bat.striker_id.isin(ids)]
    rows = []
    for pid, grp in d.groupby("striker_id"):
        P, N = grp[grp.p], grp[~grp.p]
        def st(x):
            outs = int(x.batter_out.sum())
            return dict(balls=int(len(x)), runs=int(x.runs.sum()), outs=outs, sr=round(x.runs.sum() / max(len(x), 1) * 100, 1),
                        avg=round(x.runs.sum() / outs, 1) if outs else None, dot=round(x.isdot.mean() * 100, 1),
                        bdry=round(x.bdry.mean() * 100, 1), rv100=round(x.rv.sum() / max(len(x), 1) * 100, 1))
        seas = P.groupby("year").agg(n=("rv", "size"), rv=("rv", "sum"))
        seas = seas[seas.n >= 20]
        sp = R["bat"]["split"]
        rows.append(dict(id=int(pid), name=names_bat[pid], **{"country": teams_bat[pid]["country"], "ipl_team": teams_bat[pid]["ipl"]},
                         P=st(P), NP=st(N), wpa=round(P.wpa.sum() * 100, 1), ko_balls=int((P.flag_ko).sum()),
                         matches_p=int(P.match_id.nunique()), seasons_pos=f"{int((seas.rv > 0).sum())}/{len(seas)}",
                         ipl_rv100=round(sp.loc[pid, ("rv", "IPL")] / sp.loc[pid, ("n", "IPL")] * 100, 1) if pid in sp.index else None,
                         intl_rv100=round(sp.loc[pid, ("rv", "Intl")] / sp.loc[pid, ("n", "Intl")] * 100, 1) if pid in sp.index else None))
    T = pd.DataFrame(rows).set_index("id").join(S)
    return T.sort_values("rank")

def bowl_table(r):
    S = r["S"]; ids = S.index
    d = bowl[bowl.bowler_id.isin(ids)]
    rows = []
    for pid, grp in d.groupby("bowler_id"):
        P, N = grp[grp.p], grp[~grp.p]
        def st(x):
            lg = int(x.legal.sum()); w = int(x.bowler_wkt.sum())
            return dict(balls=lg, runs=int(x.bowler_conc.sum()), wkts=w, econ=round(x.bowler_conc.sum() / max(lg, 1) * 6, 2),
                        sr=round(lg / w, 1) if w else None, dot=round(x.isdot.sum() / max(lg, 1) * 100, 1),
                        bdry=round(x.bdry.sum() / max(lg, 1) * 100, 1), rv100=round(x.rv.sum() / max(lg, 1) * 100, 1))
        seas = P.groupby("year").agg(n=("legal", "sum"), rv=("rv", "sum")); seas = seas[seas.n >= 24]
        sp = R["bowl"]["split"]
        rows.append(dict(id=int(pid), name=names_bowl[pid], country=teams_bowl[pid]["country"], ipl_team=teams_bowl[pid]["ipl"],
                         type=grp.bowling_type.mode().iloc[0], P=st(P), NP=st(N), wpa=round(P.wpa_b.sum() * 100, 1),
                         ko_balls=int(P.flag_ko.sum()), matches_p=int(P.match_id.nunique()),
                         seasons_pos=f"{int((seas.rv > 0).sum())}/{len(seas)}",
                         ipl_rv100=round(sp.loc[pid, ("rv", "IPL")] / sp.loc[pid, ("n", "IPL")] * 100, 1) if pid in sp.index else None,
                         intl_rv100=round(sp.loc[pid, ("rv", "Intl")] / sp.loc[pid, ("n", "Intl")] * 100, 1) if pid in sp.index else None))
    T = pd.DataFrame(rows).set_index("id").join(S)
    return T.sort_values("rank")

TB, TW = bat_table(R["bat"]), bowl_table(R["bowl"])

def flat(T):
    recs = []
    for pid, r in T.iterrows():
        d = {k: (None if (isinstance(v, float) and np.isnan(v)) else v) for k, v in r.items() if k not in ("P", "NP")}
        d.update({f"P_{k}": v for k, v in r.P.items()}); d.update({f"NP_{k}": v for k, v in r.NP.items()}); d["id"] = int(pid)
        for c in ["Prv_s", "Pwpa_s", "NPrv_s", "delta"]: d[c] = round(float(r[c]) * 100, 2)
        for c in ["cons_s", "impact", "volume", "score"]: d[c] = round(float(r[c]) * (100 if c == "cons_s" else 1), 3 if c != "cons_s" else 1)
        recs.append(d)
    return pd.DataFrame(recs)
FB, FW = flat(TB), flat(TW)
FB.to_csv(OUT / "batting_rankings.csv", index=False); FW.to_csv(OUT / "bowling_rankings.csv", index=False)
(OUT / "summary.json").write_text(json.dumps(log, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o)), encoding="utf-8")

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
brief = {k: v for k, v in log.items() if k not in ("LI_by_over", "pressure_share_by_over", "tiers_bat", "tiers_bowl", "closeness", "comp_mix")}
for k in ("wp_inn1", "wp_inn2"): brief[k] = {a: b for a, b in log[k].items() if a != "calibration"}
print(json.dumps(brief, default=str))
cols_b = ["rank", "name", "country", "P_balls", "P_sr", "NP_sr", "P_avg", "Prv_s", "NPrv_s", "delta", "Pwpa_s", "cons_s", "score", "rank_p05", "rank_p95", "top10_pct"]
cols_w = ["rank", "name", "country", "P_balls", "P_econ", "NP_econ", "P_wkts", "Prv_s", "NPrv_s", "delta", "Pwpa_s", "cons_s", "score", "rank_p05", "rank_p95", "top10_pct"]
print("\nBATTERS\n", FB[cols_b].head(25).to_string(index=False))
print("\nBOWLERS\n", FW[cols_w].head(25).to_string(index=False))
